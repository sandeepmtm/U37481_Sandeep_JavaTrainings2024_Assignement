package com.jsoneg;

import java.io.FileInputStream;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JSONReadeg {
	public static void main(String arg[]) throws Exception
	{
		ObjectMapper oMapper = new ObjectMapper();
		FileInputStream objFile = new FileInputStream("./sample.json");
		oMapper.readValue(objFile, Person.class);
		System.out.println("JSON file is reading\n"+objFile);
	}

}
