package com.jsoneg;

public class Address {
	String street_name;
	String city;
	String pincode;
	
	
	
	public Address() {
		super();
	}
	public Address(String street_name2, String city2, String pincode2) {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the street_name
	 */
	
	private String getStreet_name() {
		return street_name;
	}
	@Override
	public String toString() {
		return "Address [street_name=" + street_name + ", city=" + city + ", pincode=" + pincode + "]";
	}
	/**
	 * @return the city
	 */
	private String getCity() {
		return city;
	}
	/**
	 * @return the pincode
	 */
	private String getPincode() {
		return pincode;
	}
	/**
	 * @param street_name the street_name to set
	 */
	private void setStreet_name(String street_name) {
		this.street_name = street_name;
	}
	/**
	 * @param city the city to set
	 */
	private void setCity(String city) {
		this.city = city;
	}
	/**
	 * @param pincode the pincode to set
	 */
	private void setPincode(String pincode) {
		this.pincode = pincode;
	}
	
	

}
