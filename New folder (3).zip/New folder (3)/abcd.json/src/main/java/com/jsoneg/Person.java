package com.jsoneg;

import java.util.Arrays;

public class Person {
	String name;
	int agee;
	Address[] address;
	
	
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + agee + ", address=" + Arrays.toString(address) + "]";
	}
	/**
	 * @return the name
	 */
	private String getName() {
		return name;
	}
	/**
	 * @return the age
	 */
	private int getAge() {
		return agee;
	}
	/**
	 * @return the address
	 */
	private Address[] getAddress() {
		return address;
	}
	/**
	 * @param name the name to set
	 */
	private void setName(String name) {
		this.name = name;
	}
	/**
	 * @param age the age to set
	 */
	private void setAge(int age) {
		this.agee = age;
	}
	/**
	 * @param address the address to set
	 */
	private void setAddress(Address[] address) {
		this.address = address;
	}
	public Person() {
		super();
	}
	public Person(String name, int age, Address[] address) {
		super();
		this.name = name;
		this.agee = age;
		this.address = address;
	}

	
	
	

}
