package com.jsoneg;

import java.io.FileOutputStream;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class JSONWriteEg {
	public static void main(String arg[]) throws Exception
	{
		ObjectMapper oMapper = new ObjectMapper();
		ObjectNode onode = oMapper.createObjectNode();
		onode.put("name", "Ram");
		onode.put("Age", 44);
		FileOutputStream fos = new FileOutputStream ("person.json");
		String strJSON = oMapper.writeValueAsString(onode);
		
		oMapper.writeValue(fos, onode);
		System.out.println("JSON file created\n"+strJSON);

	}
}
