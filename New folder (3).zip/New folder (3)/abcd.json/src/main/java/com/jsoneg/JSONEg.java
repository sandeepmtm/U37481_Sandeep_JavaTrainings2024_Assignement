package com.jsoneg;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

import com.fasterxml.jackson.core.exc.StreamWriteException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JSONEg {
	public static void main(String arg[]) throws Exception
	{
		
		Address[] addObj = {new Address("Street1","city1","pincode1"),new Address("Street11","city11","pincode2")} ;
		
		
		Person personObj = new Person("name", 42, addObj);
		
		ObjectMapper mapper = new ObjectMapper();
		
		FileOutputStream fos = new FileOutputStream ("person.json");
		String pjson = mapper.writeValueAsString(personObj);
		System.out.println("JSON file created\n"+pjson);
	}
}
