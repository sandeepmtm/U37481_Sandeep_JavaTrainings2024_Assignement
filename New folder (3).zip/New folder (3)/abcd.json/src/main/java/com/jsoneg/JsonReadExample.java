package com.jsoneg;

import java.io.FileInputStream;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class JsonReadExample {
	public static void main(String arg[]) throws Exception
	{
		ObjectMapper oMapper = new ObjectMapper();
		FileInputStream objFile = new FileInputStream("./sample.json");
		ObjectNode onode = (ObjectNode)oMapper.readTree(objFile);
		String strJSON = oMapper.writeValueAsString(onode);
		
		
		System.out.println("JSON file read\n"+strJSON);
	}


}
