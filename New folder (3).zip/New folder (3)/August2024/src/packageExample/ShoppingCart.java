package packageExample;

import com.java170824.Product;

public class ShoppingCart {
	
	Product aprod[];
	int cindex;
	
//constructors
ShoppingCart(){
	aprod = new Product[5];
	cindex = 0;
}

//member method - add product
Product addProduct(Product prod) {
	aprod[cindex] = prod;
	cindex++;
	return prod;
}

//list of products
void listProducts(){
	for (int i=0; i<cindex; i++) {
	//	aprod[i].display().get_no_products();
	}
	
}
void emptyCart() {
	aprod = new Product[5];
	cindex =0;
	System.out.println("all products removed ");
}



void checkOut() {
	
}

}
