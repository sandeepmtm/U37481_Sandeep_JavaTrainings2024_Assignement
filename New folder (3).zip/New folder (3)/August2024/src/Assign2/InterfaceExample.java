package Assign2;


interface Circle
{
	double PI = 3.14;
	
	double getSurfaceArea(double radius);
	double getCircumference(double radius);
	
}

class InterfaceImp implements Circle{

	@Override
	public double getSurfaceArea(double radius) {
		// TODO Auto-generated method stub
		double surfacearea =  PI * (radius*radius);
		return surfacearea;
		
	}

	@Override
	public double getCircumference(double radius) {
		// TODO Auto-generated method stub
		double circumference = (2 * PI) * radius;
		return circumference;
		
	}
	
	
}
public class InterfaceExample {
	public static void main(String[] args) {
	Circle cobj = new InterfaceImp();
	double rescircum= cobj.getCircumference(2.12);
	double ressurface= cobj.getSurfaceArea(2.12);
	System.out.println("getCircumference result is: " +rescircum);
	System.out.println("getSurfaceArea result is: " +ressurface);
	
	}
	
}
