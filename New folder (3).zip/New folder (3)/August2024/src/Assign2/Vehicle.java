package Assign2;

class MyVehicles{
	
	int vId;
	String strVname;
		
	public MyVehicles(int vId, String strVname) {
		super();
		this.vId = vId;
		this.strVname = strVname;
	}
	
	

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Id: " + vId + " Vehiclename: "+strVname;
	}



	/**
	 * @return the vId
	 */
	private int getvId() {
		return vId;
	}



	/**
	 * @return the strVname
	 */
	private String getStrVname() {
		return strVname;
	}



	/**
	 * @param vId the vId to set
	 */
	private void setvId(int vId) {
		this.vId = vId;
	}



	/**
	 * @param strVname the strVname to set
	 */
	private void setStrVname(String strVname) {
		this.strVname = strVname;
	}



	static void met()
	{
		System.out.println("___________");
	}
	
}

class YourVehicles extends MyVehicles{
	
	public YourVehicles(int vId, String strVname) {
		super(vId, strVname);
		// TODO Auto-generated constructor stub
	}
		 
		
	}

public class Vehicle {
	
public static void main(String[] args) {
	MyVehicles[] arrvehicle = new YourVehicles[5];
	
	arrvehicle[0] = new YourVehicles(123, "Hyndai");
	arrvehicle[1] = new YourVehicles(123, "Ford");
	arrvehicle[3] = new YourVehicles(123, "Fiat");
	arrvehicle[4] = new YourVehicles(123, "Maruti");
	arrvehicle[2] = new YourVehicles(123, "Tata");
	
	for (MyVehicles val: arrvehicle) {
		System.out.println("Array of Vehicles:-  " +val);
	}
	
}
}

