package Assign2;

/*
1. Make constructor private
2. Create a static method for object creation
3. In above method create object only if not already created
4. use static member to find object already created
 */


//Singleton = can create one and only one object
// breaking the multiple object creation

public class ArrayUtilsSingletonBreak {
	
	
	private int array[];
	private static boolean object_created = false;
	private static ArrayUtilsSingletonBreak m_obj = null;

	//constructor
	private ArrayUtilsSingletonBreak(int array[]) {
		this.array = array;
	}
	
	
	
	public static ArrayUtilsSingletonBreak getInstance(int array[]) {
		//ArrayUtils2 obj = m_obj;
		
		if(object_created == false) {
			//obj = new ArrayUtils2(array);
			m_obj = new ArrayUtilsSingletonBreak(array);
			object_created = true;
		//	m_obj = obj;
		}
	//	return obj;
		return m_obj;
	}
	
	public int min() {
		int min_val = array[0];
		for (int i = 0; i < array.length; i++) {
			if (array[i] < min_val) {
				min_val = array[i];
			}
		}

		return min_val;
	}
	//max
	
	//avg
	
	//etc...

}