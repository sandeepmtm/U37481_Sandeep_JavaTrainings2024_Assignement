package Assign2;

class Product1 {
	int Id=0;
	String name;
	
	final void display() {
		System.out.println("base class");
	}
	
	final void displaye() {
		System.out.println("base class");
	}
	
	@Override
	public String toString() {
		return "Id" +Id;
	}
	
	
}

class ElectronicProduct1 extends Product1{
	float voltage;
	public ElectronicProduct1(int i, String string) {
		// TODO Auto-generated constructor stub
	}

	void displaying() {
		System.out.println("derived class");
	}
	
	@Override
    public boolean equals(Object o) {
 
        // If the object is compared with itself then return true  
        if (o == this) {
            return true;
        }
		return false;
 
	
}
public class Equals_Assignment {
	public static void main(String[] args) {
		
		//Product obj = new ElectronicProduct();
	//	obj.display();
		 Product1 obj = new ElectronicProduct1(1, "name");
		 Product1 obj1 = new ElectronicProduct1(1, "name1");
		System.out.println("derived class: " +obj.toString());
		System.out.println("notffiy: " +obj.toString());
		obj.display();
		
		 if (obj.equals(obj1)) {
	            System.out.println("Equal ");
	        } else {
	            System.out.println("Not Equal ");
	        }
	}
}
}
