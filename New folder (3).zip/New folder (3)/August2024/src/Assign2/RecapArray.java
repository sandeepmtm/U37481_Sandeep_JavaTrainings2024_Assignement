package Assign2;

public class RecapArray {
	
	private int array[];
	private static boolean object_created = false;

	//constructor
	private RecapArray(int array[]) {
		this.array = array;
	}
	
	public static RecapArray getInstance(int array[]) {
		RecapArray obj = null;
		if(object_created == false) {
			obj = new RecapArray(array);
			object_created = true;
		}
		return obj;
	}
	
	public int min() {
		int min_val = array[0];
		for (int i = 0; i < array.length; i++) {
			if (array[i] < min_val) {
				min_val = array[i];
			}
		}

		return min_val;
	}
	
	//max
	
	//avg
	
	//etc...
		
}


//https://codefile.io/f/h8LoXRob9q



/*
1. Make constructor private
2. Create a static method for object creation
3. In above method create object only if not already created
4. use static member to find object already created
*/


//Singleton = can create one and only one object


//===========================


