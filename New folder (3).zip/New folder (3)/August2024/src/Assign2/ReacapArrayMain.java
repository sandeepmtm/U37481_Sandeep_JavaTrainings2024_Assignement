package Assign2;

import java.util.Scanner;

public class ReacapArrayMain {
	
	public static void main(String[] args) {
		int arr[] = new int[5];
		Scanner scnr = new Scanner(System.in);
		
		for(int i = 0; i < 5; i++) {
			System.out.println("Enter next value, and press enter");
			int val = scnr.nextInt();
			arr[i] = val;
		}
		
		RecapArray obj = RecapArray.getInstance(arr);
		int min_result = obj.min();
		
		RecapArray obj1 = RecapArray.getInstance(arr);
		RecapArray obj2 = RecapArray.getInstance(arr);
		System.out.println(min_result);
	}

}
