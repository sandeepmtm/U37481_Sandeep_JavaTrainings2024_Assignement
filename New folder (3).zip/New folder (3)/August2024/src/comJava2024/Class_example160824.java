package comJava2024;


public class Class_example160824 {
	public static void main(String[] args) {
		Product objProd = new Product();
		objProd.productId = 10;
		objProd.productName = "Mobile";
		objProd.stockStatus	=	true;
		
		Product objProdarr[] = new Product[3];
		
		objProdarr[0] = new Product(10, "Mobile");
		objProdarr[1] = new Product(20, "TV");
		objProdarr[2] = new Product(30, "Laptop");

		//enhanced for loop
		for (Product dprod: objProdarr)
		{
		   dprod.display();
		}
		
		
		objProd.display();
		
	//	for (i=0; objProd.length<=3; i++)
			
		
	}
	
}


 class Product{
	 
	 
	 	int productId;
		String productName;
		float productPrice;
		boolean stockStatus;
		
		Product ()
		{
			productPrice=0;
		}
		Product( int Id, String pName){
			productId = Id;
			productName = pName;
			
		}
		
		void display ()
		{
			System.out.println(" ID: " +productId + "    Name: "+productName);
		}

 }
	
