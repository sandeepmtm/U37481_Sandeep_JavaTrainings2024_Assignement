package comJava2024.Assignements.Aug12and13_Assignments;

public class Print_Number_in_digits_13Aug_Assignment {
	
	public static void main(String[] args) {
	
	int number =12345, digits; 
	
	while (number > 0) {
	   
	    digits = number%10;  
	    number = number / 10;
	    System.out.println(" digits are:  " +digits);
	  
	}
	
  }
}
