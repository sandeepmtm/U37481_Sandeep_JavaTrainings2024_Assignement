package comJava2024.Assignements.Aug12and13_Assignments;

public class Assignment_recheck_primeornot {
	
	public static void main (String[] arg)
	{
		IsPrimeNumberorNot(12);
		
	}
	
	static void IsPrimeNumberorNot(int primeNo) {
		    boolean isPrime = false;
            for (int j = 2; j < primeNo - 1; j++) {
                if (primeNo % j == 0) {
                    isPrime = false;
                    break;
                }
            }
         if(isPrime == true)   
         {
        	 System.out.println(primeNo+ ":   is a Prime Number");
         }
         else
         {
        	 System.out.println(primeNo+ ":   is not a Prime Number");
         }
	}
}


