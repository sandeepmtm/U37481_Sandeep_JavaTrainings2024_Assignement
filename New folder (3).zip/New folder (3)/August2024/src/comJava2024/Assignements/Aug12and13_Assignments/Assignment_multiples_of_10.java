
// Assignment-2: multiplication table with nested loop
package comJava2024.Assignements.Aug12and13_Assignments;

public class Assignment_multiples_of_10 {

	public static void main(String[] args) {
		
		
		for (int i=1; i<=10; i++)
		{
			for (int j=1; j<=10; j++)
			{
				System.out.println(i + " X " + j + " = "+ i*j);
			}
		}

	}

}
