package comJava2024.Assignements.Aug12and13_Assignments;

public class Average_petrol_price_city_13Aug {
	
	public static void main(String[] args) {
		
		double Mumbai = 101.90, Chennai =102.00, Delhi = 101.34, Hyderabad = 102.29, Bangalore = 102.00, Kolkotta = 101.98 ; 
		
		System.out.println("Average of five numbers is: " + (Mumbai + Chennai + Delhi + Hyderabad + Bangalore + Kolkotta) / 6);
		  
		}
		
	  

}
