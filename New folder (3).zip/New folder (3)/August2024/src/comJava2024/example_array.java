package comJava2024;

public class example_array {
	public static void main(String[] args) {
		int pincome [] = new int[5];
		pincome[0] = 400;
		pincome[1] = 4001;
		pincome[2] = 423;
		pincome[3] = 4234;
		pincome[4] = 41;
		
		print(pincome);
	//	int mini_income = minincome(pincome);
		int[] rpincome = reverse(pincome);
		System.out.println(" reversed array below.... ");
		print(rpincome);
		
		for (int i=0; i< pincome.length; i++)
		{
			System.out.println(" Per capita" + " " +i+ "  is   " +pincome[i]);
		}
		
		for (int i= pincome.length-1; i>=0; i--)
		{
			System.out.println(" from last Per capita" + " " +i+ "  is   " +pincome[i]);
		}
		
		int min_income = pincome[0];
		for (int i= 1; i<pincome.length; i++)
		{
			if (min_income > pincome[1])
			{
				min_income = pincome[1];
			}
			
		}
	//	System.out.println(" minimum income is "  + min_income);

		for (int i= 1; i<pincome.length; i++)
		{
			if (min_income < pincome[1])
			{
				min_income = pincome[1];
			}
			
		}
		int min_income1 = minincome(pincome);
		
		int min_income2 = minincome1(pincome);
		
	//	int min_income3 [] = reverse(pincome);
		
		System.out.println(" min income is "  + min_income1);
		System.out.println(" max income is "  + min_income2);
	//	System.out.println(" reverse  "  + min_income3);
	}
		
		static int minincome(int [] avalues) {
			int min_income1 = avalues[0];
			for (int i= 1; i<avalues.length; i++)
			{
				if (min_income1 > avalues[1])
				{
					min_income1 = avalues[1];
				}
		}
			return min_income1;
		}
			
			static int minincome1(int [] avalues1) {
				int min_income2 = avalues1[0];
				for (int i= 1; i<avalues1.length; i++)
				{
					if (min_income2 < avalues1[1])
					{
						min_income2 = avalues1[1];
					}
			}
				return min_income2;			
		}
			
			static void print(int [] arr) {
				System.out.println(" begin ...... ");
				for (int i=0; i< arr.length; i++)
				{
					System.out.println(" Per capita" + " " +i+ "  is   " +arr[i]);
				}
				System.out.println(" end ...... ");
				
			}
			
			static int[] reverse (int [] avalues){
				int n  = avalues.length, tmp;
				
				for (int i=0; i<n/2; i++) {
					
					tmp = avalues[i];
					avalues[i] = avalues[n-i-1];
					
					avalues[n-i-1] = tmp;
					//System.out.println(" reversed  "  + avalues[n-i-1] );
					
				}
				return avalues;
				
			}
}

