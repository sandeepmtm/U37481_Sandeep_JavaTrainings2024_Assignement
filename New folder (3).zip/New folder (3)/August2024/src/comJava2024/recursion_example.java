package comJava2024;

public class recursion_example {
	
	public static void main(String[] args) {
	    
		System.out.println(" Factorial:  " +fact(5));
		
		
	}

	static int fact(int n) {
		if(n==1)
		{
			return 1;
		}
		else 
		{
			return (n*fact(n-1));
		}
	}
	
}
