package comJava2024;

//import java.util.Scanner;

public class ShoppingCart{
	//data members
	//array of products
	
	Product aprod[];
	int cindex;
	
//constructors
ShoppingCart(){
	aprod = new Product[5];
	cindex = 0;
}

//member method - add product
Product addProduct(Product prod) {
	aprod[cindex] = prod;
	cindex++;
	return prod;
}

//list of products
void listProducts(){
	for (int i=0; i<cindex; i++) {
		aprod[i].display();
	}
	
}
void emptyCart() {
	aprod = new Product[5];
	cindex =0;
	System.out.println("all products removed ");
}



void checkOut() {
	
}
}

 class Product{
		 
	int productId;
	String productName;
	float productPrice;
	boolean stockStatus;
	static int no_of_products = 100;
	
	Product ()
	{
		productPrice=0;
	}
	Product( int Id, String pName){
		productId = Id;
		productName = pName;
		
	}
	
	void display ()
	{
		System.out.println(" ID: " +productId + "    Name: "+productName);
		
	}
	
	public static int get_no_products() {
		return no_of_products;
	}

}

public class static_example_170824 {
	
	public static void main(String[] args) {
		
	
		
	ShoppingCart scart = new ShoppingCart();
	System.out.println(" total no of products: "+Product.get_no_products());
	
	Product p1 = new Product(10, "Mobile");
	scart.addProduct(p1);
	
	Product p2 = new Product(20, "TV");
	scart.addProduct(p2);
	
	
	scart.listProducts();
	
	
	}

	
	}


