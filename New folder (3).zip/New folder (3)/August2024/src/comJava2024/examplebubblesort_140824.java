package comJava2024;

public class examplebubblesort_140824 {
public static void main(String[] args) {

int pincome[] = {82, 52, -2, 31, 26, 11 };

System.out.println("Array before sorting...");

print(pincome);

int[] rpincome = sort(pincome);

System.out.println("Array after sorting......");

print(rpincome);

}

static int[] sort(int[] avalues) {

for (int i = 0; i < avalues.length; i++) {

for (int j = 0; j < avalues.length - 1 - i; j++) {

if (avalues[j] > avalues[j + 1]) {

int tmp = avalues[j];

avalues[j] = avalues[j + 1];

avalues[j + 1] = tmp;

}

}

}

return avalues;

}

static void print(int[] arr) {

System.out.println("----------------Display Begin--------------");

for (int i = 0; i < arr.length; i++) {

System.out.println("PerCapita income of City " + i + " is " + arr[i]);

}

System.out.println("----------------Display End--------------");

}

}

/*
 * public class examplebubblesort_140824 {
 * 
 * public static void main(String[] args) { int pincome[] = {24, -2, 56, 100, 3,
 * 78, 89};
 * 
 * System.out.println(" before starting ....... ");
 * 
 * int[] rpincome = sort(pincome);
 * 
 * System.out.println(" after sorting........ ");
 * 
 * print(rpincome);
 * 
 * 
 * }
 * 
 * static int[] sort (int [] avalues){
 * 
 * 
 * for (int i=0; i<avalues.length; i++) { for (int j=0; i<avalues.length-1-i;
 * j++) {
 * 
 * if (avalues[j] > avalues[j+1]) { int tmp = avalues[j]; avalues[j] =
 * avalues[j+1];
 * 
 * avalues[j+1] = tmp; //System.out.println(" reversed  " + avalues[n-i-1] ); }
 * }
 * 
 * } return avalues;
 * 
 * }
 * 
 * 
 * static void print(int [] arr) { System.out.println(" begin ...... "); for
 * (int i=0; i< arr.length; i++) { System.out.println(" Per capita" + " " +i+
 * "  is   " +arr[i]); } System.out.println(" end ...... ");
 * 
 * }
 * 
 * }
 */
