package com.java170824;

public class Animal1 {
	
	public void move() {
		// TODO Auto-generated method stub
		System.out.println("crawling");
	}

}
