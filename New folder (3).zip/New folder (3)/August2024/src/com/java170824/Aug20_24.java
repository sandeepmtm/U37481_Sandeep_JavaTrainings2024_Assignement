package com.java170824;

public abstract class Aug20_24 {

    // Abstract method, must be implemented by subclass
    abstract void move();

    // Concrete method, can be used as is or overridden
    void eat() {
        System.out.println("eat");
    }

    // Inner class Snake1 that extends Aug20_24
    class Snake1 extends Aug20_24 {

        @Override
        public void move() {
            // Implementing the abstract method move
            System.out.println("crawling1");
        }
    }

    public static void main(String[] args) {
        // Creating an instance of Snake1 and invoking the move method
        Aug20_24 snake = new Aug20_24() {  // Using anonymous class for Snake1
            @Override
            void move() {
                System.out.println("crawling");
            }
        };
        
        snake.move();
        snake.eat();
    }
}
