package com.java170824;

public class TemporaryEmployee extends Employee{
	
	float hourlypay;
	String company_address;

	public TemporaryEmployee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TemporaryEmployee(int eid, String name, float hourlypay, String company_address) {
		super(eid, name);
		this.hourlypay = hourlypay;
		this.company_address = company_address;
		// TODO Auto-generated constructor stub
	}
	
	public void display() {
		displaye();
		System.out.println("Hourly Payment: " +hourlypay + " Address: " +company_address);
	}

}
