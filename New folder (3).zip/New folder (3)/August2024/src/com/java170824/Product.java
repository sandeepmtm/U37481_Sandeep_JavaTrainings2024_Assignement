package com.java170824;

public class Product{
	 
	private int productId;
	private String productName;
	private float productPrice;
	private boolean stockStatus;
	private static int no_of_products = 100;
	final static int MAX_VAL =1000;
	
	Product ()
	{
		productPrice=0;
	}
	Product( int Id, String pName){
		this();
		productId = Id;
		productName = pName;
		
		
		
	}
		
	
	/**
	 * @return the productId
	 */
	public int getProductId() {
		return productId;
	}
	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}
	/**
	 * @return the productPrice
	 */
	public float getProductPrice() {
		return productPrice;
	}
	/**
	 * @return the stockStatus
	 */
	public boolean isStockStatus() {
		return stockStatus;
	}
	/**
	 * @return the no_of_products
	 */
	public static int getNo_of_products() {
		return no_of_products;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(int productId) {
		this.productId = productId;
	}
	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}
	/**
	 * @param productPrice the productPrice to set
	 */
	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}
	/**
	 * @param stockStatus the stockStatus to set
	 */
	public void setStockStatus(boolean stockStatus) {
		this.stockStatus = stockStatus;
	}
	/**
	 * @param no_of_products the no_of_products to set
	 */
	public static void setNo_of_products(int no_of_products) {
		Product.no_of_products = no_of_products;
	}
	
	
	public void display ()
	{
		System.out.println(" ID: " +productId + "    Name: "+productName);
		
	}
	
	/*
	 * public Product display1() { System.out.println(" ID: " +productId +
	 * "    Name: "+productName);
	 * 
	 * }
	 */
	
	static int get_no_products() {
		return no_of_products;
	}

}
