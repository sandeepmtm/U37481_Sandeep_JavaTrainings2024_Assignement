package Assign1;

import com.java170824.PermanentEmployee;
import com.java170824.TemporaryEmployee;

public class MainProgram {
	
	public static void main(String[] args) {
		final PermanentEmployee pobj = new PermanentEmployee(110, "San", 145.5f, "address1");
		pobj.displaye();
		
		TemporaryEmployee tobj = new TemporaryEmployee(111, "Deep",1000.55f, "Trivandrum");
		tobj.display();
	}
}
