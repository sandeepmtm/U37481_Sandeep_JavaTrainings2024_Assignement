package Assign1;

class Product {
	int Id=0;
	String name;
	
	void display() {
		System.out.println("base class");
	}
	
	Product(int Id, String name){
		this.Id=Id;
		this.name=name;
	}
	
	public String toString() {
		return "Id= " +Id;
	}
	
	 
	
	 }    
class ElectronicProduct extends Product{
	
	ElectronicProduct(int Id, String name) {
		super(Id, name);
		// TODO Auto-generated constructor stub
	}
	float voltage;
	void display() {
		System.out.println("derived class");
	}
	
	
	
}

public class MethodOveride_Example {
	public static void main(String[] args) {
		
		
		
		//Product obj = new ElectronicProduct();
	//	obj.display();
		Product obj = new ElectronicProduct(1, "name1");
		Product obj1 = new ElectronicProduct(1, "name2");
		
		
		System.out.println("derived class: " +obj.toString());
		System.out.println("notffiy: " +obj.toString());
		obj.display();
	}

}

