package Assign1;

abstract class Animal{
	
	String nameofanimal;
	
	
	
	public Animal(String nameofanimal) {
		super();
		this.nameofanimal = nameofanimal;
	}

	abstract void move();
	
	void eat() {
		System.out.println("eat");
	}
}

class Snake extends Animal{

	public Snake(String nameofanimal) {
		super(nameofanimal);
		// TODO Auto-generated constructor stub
	}

	@Override
	void move() {
		// TODO Auto-generated method stub
		System.out.println("crawling");
	}
	
	
}

public class AbstractClassMethods {
	public static void main(String[] args) {
		Animal obj = new Snake("lizard");
		obj.move();
	}
	

}
