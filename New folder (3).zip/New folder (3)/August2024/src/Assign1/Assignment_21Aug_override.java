package Assign1;

class Department{
	private int id;
	private String deptname;
	private String hod_name;
	
	//constructor
	public Department(int id, String deptname, String hod_name) {
		this.id = id;
		this.deptname = deptname;
		this.hod_name = hod_name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public String getHod_name() {
		return hod_name;
	}

	public void setHod_name(String hod_name) {
		this.hod_name = hod_name;
	}
	
	//setter, getter methods
}


class University{
	String name;
	String address;
	Department depts[];
	public University(String name, String address, Department[] depts) {
		super();
		this.name = name;
		this.address = address;
		this.depts = depts;
	}
	/**
	 * @return the name
	 */
	private String getName() {
		return name;
	}
	/**
	 * @return the address
	 */
	private String getAddress() {
		return address;
	}
	/**
	 * @return the depts
	 */
	private Department[] getDepts() {
		return depts;
	}
	/**
	 * @param name the name to set
	 */
	private void setName(String name) {
		this.name = name;
	}
	/**
	 * @param address the address to set
	 */
	private void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @param depts the depts to set
	 */
	private void setDepts(Department[] depts) {
		this.depts = depts;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "University: " +name+ "Address: " +address+ "Department: " +depts;
	}
	
	
	
	
	
	//constructor
	
	//setter getter
	//toString
	
}




public class Assignment_21Aug_override {
	public static void main(String[] args) {
		
		//create atleast two departments, 
		Department [] deparr = new Department[2];	
		deparr[0] = new Department(1, "Physics", "HOD1");
		deparr[1] = new Department(2, "Economics", "HOD2");
		
		//and set those 2 departments to University object
		University[] univ = new University[3];	
		univ[0] = new University("University1","address1",deparr );
		
		
		//display university object
		for (University val: univ) {
			System.out.println("University: " +val);
			for(Department d: deparr)
			{
				System.out.println("University: " +d);
			}
			
		}
		
		
	}
}

