package coll_streams;

import java.util.*;

public class Map_eg {
	
	
	public static void main(String[] args) {
		HashMap<String, String> hmss = new HashMap<>();
		//no order, no duplicates
		
		hmss.put("name1", "msg1");
		hmss.put("name7", "msg7");
		hmss.put("name2", "msg2");
		hmss.put("name3", "msg3");
		hmss.put("name4", "msg4");
		hmss.put("name5", "msg5");
		hmss.put("name6", "msg6");
		hmss.put("name6", "msg6");
		
		Set<String> ss = hmss.keySet();
		
		for(String item_key : ss) {
			System.out.println(item_key + " --> "+hmss.get(item_key));
		}
	}

}
