import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class LongestStringExample { 

	public static void main(String[] args) 
	{ 
		// Initialize list of Strings
		List<String> words = Arrays.asList("kkkkkkkkkkkkkkk", "AAA", "bbbbb", "zzzzzz", 
										"ccccccccccc"); 

		//Provide lamba expression to reduce(). This lambda expression checks for 
		//largest string for given two Strings, and use conditional ?: operator
		Optional<String> largestStr = words.stream()
				.reduce((pStr, nStr) -> pStr.length() > nStr.length() ? pStr : nStr); 

		String str;
		if(largestStr.isPresent())
		{
			str = largestStr.get();
		}
		else
		{
			str = "Largest String not found";
		}
		
		System.out.println(str);

	} 
} 