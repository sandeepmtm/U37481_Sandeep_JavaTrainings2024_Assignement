package com.example;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.Comparator;

public class LamdaCollection_eg {
	TreeSet<Country> cc = new TreeSet<Country>(
//		(c1,c2)-> {return(int) (c1.cgdp()) - (c2.cgdp());}
//		);
			(c1,c2)-> {(int) (c1.cgdp()) - (c2.cgdp());})
	
	cc.add(new Country("name1", 123));
	cc.add(new Country("name1", 123));
	cc.add(new Country("name2", 124));
	cc.add(new Country("name3", 125));
	cc.add(new Country("name2", 124));
	
	
	Iterator itrs = cc.iterator();
	
	for (;itrs.hasNext();) {
		System.out.println(itrs.next());
	}
}


}
