package com.example;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class TreeSet_eg {
	public static void main(String args[])
	{
		TreeSet<String> num = new TreeSet<>(new MyComparator());
		
		num.add("aaaa");
		num.add("zzz");
		num.add("vvvc");
		num.add("ddd");
		num.add("qqq");
		num.add("yyy");
		num.add("ccc");
		
		Iterator itrs = num.iterator();
		
		for (;itrs.hasNext();) {
			System.out.println(itrs.next());
		}
}

}

class MyComparator implements Comparator<String>{

	@Override
	public int compare(String o1, String o2) {
		// TODO Auto-generated method stub
		return o2.compareTo(o1);
	}
	
}
