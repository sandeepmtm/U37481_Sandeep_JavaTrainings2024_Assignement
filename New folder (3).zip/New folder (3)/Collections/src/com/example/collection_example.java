package com.example;

import java.util.*;
import static java.lang.System.*;


 class Cities{
	
	private String name;
	private long pincode;
	private String capital_city;
	
	//constructor
	public Cities(String name, long pincode, String capital_city) {
		this.name = name;
		this.pincode = pincode;
		this.capital_city = capital_city;
	}
	
	//getter, setter - TBD
	
	//toString
	@Override
	public String toString() {
		return "City [name=" + name + ", pincode=" + pincode + ", capital_city=" + capital_city + "]";
	}
}



public class collection_example {
	
	public static void main(String args[])
	{	
		
		List<Cities> city = new ArrayList<Cities>();
	
		city.add(new Cities("name1", 123, "cap1"));
		city.add(new Cities("name1", 123, "cap1"));
		city.add(new Cities("name2", 124, "cap2"));
		city.add(new Cities("name3", 125, "cap2"));
		
		System.out.println(city);
		Collections.reverse(city);
		
		System.out.println(city);		
		
		Collections.reverse(city);
		static void  display (List<Cities> lcity, String msg)
		{
		System.out.println(msg);
		
		Iterator<Cities> itr = lcity.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		
}

}
