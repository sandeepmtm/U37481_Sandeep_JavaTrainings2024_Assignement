package com.example;

import java.util.*;
import java.util.Map.Entry;

public class LinkedHashMap_eg {
	public static void main(String[] args) {
		LinkedHashMap<String,Integer> lhs = new LinkedHashMap<>();
		//no order; no duplicates
		
		lhs.put("CCC", 2);
		lhs.put("ABC", 4);
		lhs.put("EFG", 5);
		lhs.put("FGC",1);
		lhs.put("CCC", 3);
		lhs.put("CCC",1);
		lhs.put("ERT", 2);
		lhs.put("CCSC", 1);
		
		Set<Entry<String,Integer>> sss = lhs.entrySet();
		for(Entry<String,Integer> esg : sss)
		{
			System.out.println(esg.getKey()+ " : "+esg.getValue());
		}
	}

}
