package com.example;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;

class Chats{
	private String chat_name;
	private String chat_msg;
	public Chats(String chat_name, String chat_msg) {
		super();
		this.chat_name = chat_name;
		this.chat_msg = chat_msg;
	}
	/**
	 * @return the chat_name
	 */
	private String getChat_name() {
		return chat_name;
	}
	/**
	 * @return the chat_msg
	 */
	private String getChat_msg() {
		return chat_msg;
	}
	/**
	 * @param chat_name the chat_name to set
	 */
	private void setChat_name(String chat_name) {
		this.chat_name = chat_name;
	}
	/**
	 * @param chat_msg the chat_msg to set
	 */
	private void setChat_msg(String chat_msg) {
		this.chat_msg = chat_msg;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
}

public class LinkedList_Objects_eg_assignment {
	public static void main(String[] args) {
		TreeSet<Chats> msg = new TreeSet<>(new TSComparator());
		msg.add(new Chats ("P13", "D"));
		msg.add(new Chats("P2", "S"));
		msg.add(new Chats ("P9", "d"));
		msg.add(new Chats("P8", "N"));
		msg.add(new Chats ("P13", " e"));
		msg.add(new Chats ("P5","Y"));
		//msg.add("P8 - I");
	//	msg.add("P9 - completed");

		msg.add(3, "Trainer - any questions?");

		//2 - update 4th element with "P10 - I"
		msg.set(4,"p10-I");

		//3 - remove 2nd element
		msg.remove(2);

		display(msg);

		int done = 0, notdone = 0, error = 0, others = 0;
		for(String mg: msg){
		if(mg.indexOf("D")>0 || mg.indexOf("d")>0 || mg.indexOf("completed")>0){
		done++;
		}
		else if(mg.indexOf("E")>0 || mg.indexOf("e")>0){
		error++;
		}
		else if(mg.indexOf("N")>0){
		notdone++;
		}
		else{
		others++;
		}
		}

		System.out.println("No. of Done is "+done);
		System.out.println("No. of Not Done is "+notdone);
		System.out.println("No. of Errors is "+error);
		System.out.println("No. of Others is "+others);

		Collections.shuffle(msg);

		System.out.println("Msgs after SHuffling");
		display(msg);
		}

		static void display(List<String> list){
		for(String str:list){
		System.out.print(str+"\t");
		}
		}
class TSComparator implements Comparator<Chats>{

	@Override
	public int compare(Chats o1, Chats o2) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
}
