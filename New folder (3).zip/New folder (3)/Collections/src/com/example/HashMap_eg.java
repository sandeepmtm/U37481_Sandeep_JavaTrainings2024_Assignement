package com.example;
import java.util.Map.Entry;
import java.util.*;




public class HashMap_eg {
	
	public static void main(String args[])
	{
		Map<String, String> hss = new HashMap<>();
		
		hss.put("Kerala", "Kochi" );
		hss.put("Kerala", "Kannur" );
		hss.put("Kerala", "Trissor" );
		
		Set<Entry<String,String>> ss = ss.entrySet();
		Iterator<Entry<String,String>> itss = itss.iterator();
		
		while(itss.hasNext()) {
			Entry<String,String> s = s.next();
			System.out.println(s.getKey()+ "->" +s.getValue());
		}
		
		for(itss.hasNext() s: ss) {
			
			System.out.println(s.getKey()+ "->" +s.getValue());
		}
	}

}
