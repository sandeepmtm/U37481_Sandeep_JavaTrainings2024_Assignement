package com.example;

class Wrapper<T> {
	T data;

	// setter
	void setData(T data) {
		this.data = data;
	}

	// getter
	T getData() {
		return data;
	}
}


	

	//Generic class
	

public class GenericClass {
	public static void main(String[] args) {
		Wrapper<String> ws = new Wrapper<String>();
		//...
		
		Wrapper<Cities> wc = new Wrapper<Cities>();
		//...
		
		String str ="25";
		int val =Integer.valueOf(str);
		
		System.out.println(val);
	}
	}


