package com.example;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Optional;

import com.example.HashMap_example.State;

import java.util.List;

public class StreamExample_my {
	
	public static void main(String[] args) 
	{ 
		
		HashSet<State> alist = new HashSet<>();
		
		alist.add(new State("state32", 123214));
		alist.add(new State("state322", 1232714));
		alist.add(new State("state312", 1232314));
		
		alist.stream().filter((e) -> e.getPopulation() > 63432).forEach((obj) ->{System.out.println("  ")}};
		alist.stream().filter((e) -> e.getPopulation() > 63432).forEach((obj) ->{System.out.println("  ")}};
		Optional <State> os = alist.stream().reduce (s1,s2)->{return s1.getPopulation()>s2.getPopulation

		/*
		 * // filter / Map /reduce Creating a list of Integers List<Integer> list =
		 * Arrays.asList(3, 4, 15, 6, 12, 20);
		 * 
		 * Optional <Integer> result = list.stream().filter((e) -> e >10).map((e) -> e
		 * *2).forEach(obj).;; System.out.println(e);
		 */
	}

}
