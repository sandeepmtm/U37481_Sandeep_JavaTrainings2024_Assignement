package com.example;



import java.util.*;

class City{
	private String name;
	private long pincode;
	private String state;
	
	//constructor
	public City(String name, long pincode, String capital_city) {
		this.name = name;
		this.pincode = pincode;
		this.state = capital_city;
	}
	
	//getter, setter - TBD
	
	//toString
	@Override
	public String toString() {
		return "City [name=" + name + ", pincode=" + pincode + ", state=" + state + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(name, pincode, state);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		City other = (City) obj;
		return Objects.equals(name, other.name) && pincode == other.pincode && Objects.equals(state, other.state);
	}
	
	
}

public class Assignment_Scanner {
public static void main(String[] args) {
	//create List
	List<City> cities = new LinkedList<City>();
	Scanner scnr = new Scanner(System.in);
	
	//add City objects to List
	cities.add(new City("city1", 1234, "capital1"));
	cities.add(new City("city2", 3456, "capital2"));
	
	System.out.println("Please enter city name");
	String icity = scnr.next();
	
	System.out.println("Please enter pincode");
	long ipincode = scnr.nextLong();
	
	System.out.println("Please enter State name");
	String istate = scnr.next();
	
	cities.add(new City(icity, ipincode, istate));
	
	//iterate and display
	Iterator<City> itr = cities.iterator();
	
	while(itr.hasNext()){
		System.out.println(itr.next());
	}
	
	
}
}
