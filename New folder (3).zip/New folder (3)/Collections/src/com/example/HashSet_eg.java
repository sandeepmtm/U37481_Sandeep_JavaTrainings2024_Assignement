package com.example;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class HashSet_eg {
	
	public static void main(String args[])
	{

		
		
		HashSet<Integer> num = new HashSet<>();
		HashSet<City> city = new HashSet<>();
		num.add(4435);
		
		num.add(2342);
		num.add(2343);
		num.add(44);
		num.add(1);
		num.add(5234);
		num.add(1);
		
		
		city.add(new City("name1", 123, "cap1"));
		city.add(new City("name1", 123, "cap1"));
		city.add(new City("name2", 124, "cap2"));
		city.add(new City("name3", 125, "cap2"));
		city.add(new City("name2", 124, "cap2"));
		
		for (Integer element: num) {
			System.out.println(element);
		}
	
		for (City element: city) {
			System.out.println(element);
		}
}

}
