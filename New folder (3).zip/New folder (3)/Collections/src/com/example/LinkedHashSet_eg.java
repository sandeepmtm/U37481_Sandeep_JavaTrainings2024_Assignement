package com.example;

import java.util.*;

public class LinkedHashSet_eg {
	public static void main(String[] args) {
		LinkedHashSet<String> lhs = new LinkedHashSet<>();
		//maintain order; no duplicates
		
		lhs.add("CCC");
		lhs.add("AAA");
		lhs.add("VVV");		
		lhs.add("AAA");
		lhs.add("CCC");
		
		lhs.add("MTM");
		lhs.add("DDD");
		lhs.add("PPP");
		lhs.add("ZZZ");
		lhs.add("GGGG");
		
		lhs.stream().forEach((item)->{System.out.println(item);});
	}
}
