package com.example;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

class Country{
	
	private String cname;
	private double cgdp;
	public Country(String cname, double cgdp) {
		super();
		this.cname = cname;
		this.cgdp = cgdp;
	}
	@Override
	public String toString() {
		return "Country [cname=" + cname + ", cgdp=" + cgdp + "]";
	}
	
	
	
}


public class TreeSet_desc {
	public static void main(String args[])
	{
	TreeSet<Country> elemnet = new TreeSet<Country>(new MyComparator());
	
	elemnet.add("India");
	elemnet.add("zzz");
	elemnet.add("vvvc");
	elemnet.add("ddd");
	elemnet.add("qqq");
	elemnet.add("yyy");
	elemnet.add("ccc");
	
	Iterator itrs = num.iterator();
	
	for (;itrs.hasNext();) {
		System.out.println(itrs.next());
	}
}
}
}


class MyComparator implements Comparator<Integer>{

	@Override
	public int compare(Country o1, Country o2) {
		// TODO Auto-generated method stub
		return int(o2.getClass()- int(o1.getClass());
	}



}
