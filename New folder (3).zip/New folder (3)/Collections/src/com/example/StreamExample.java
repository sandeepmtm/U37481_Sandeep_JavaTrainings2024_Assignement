package com.example;

public class StreamExample {
	
	
	public static void main(String[] args) 
	{ 
		C obj = new C();
		obj.display();
		
		System.out.println(obj);
		
	}


}


class A{
	
	public void display() {
	System.out.println("One");
	}
}
class B extends A {
	
	public void display() {
	System.out.println("Two");
	}
}
class C extends B{
	
	public void display() {
	System.out.println("Three");
	}
}