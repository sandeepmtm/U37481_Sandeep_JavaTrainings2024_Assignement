package com.ecom.app.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/* to specify Handler method for an exception in this Project */
@ControllerAdvice
public class ProductExceptionHandler {

	/* whatever returned from this method is given back to client, during exeception scenario */
	@ExceptionHandler(InvalidProductIDException.class)
	ResponseEntity<String> met(InvalidProductIDException excep){
		return new ResponseEntity<String>(excep.getMessage(), HttpStatus.NOT_FOUND);
	}
	

	@ExceptionHandler(InvalidNameException.class)
	ResponseEntity<String> handler(InvalidNameException excep){
		return new ResponseEntity<String>(excep.getMessage(), HttpStatus.BAD_REQUEST);
	}
}
