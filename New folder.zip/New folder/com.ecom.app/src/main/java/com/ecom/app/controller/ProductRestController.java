package com.ecom.app.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecom.app.exception.InvalidNameException;
import com.ecom.app.exception.InvalidProductIDException;
import com.ecom.app.model.Products;
import com.ecom.app.service.ProductService;


import jakarta.validation.Valid;

@RestController
@RequestMapping("/products")
public class ProductRestController {

	@Autowired
	ProductService pService;
	// Dependency Injection


	@GetMapping("/{pid}")
	ResponseEntity<Products> getTicket(@PathVariable("pid") int productid) {

		Products products = pService.getProductsServ(productid);

		if (products == null)   {
			throw new InvalidProductIDException("No such ticket  exists");
		}

		return new ResponseEntity<Products>(products, HttpStatus.OK);

	
	}

	
	@GetMapping("/name/{name}")
	ResponseEntity<List<Products>> getProductName(@PathVariable String name) {
		List<Products> lproducts = pService.getProductsName(name);
		System.out.println("PRODUCT NAME DISPLAYED..........");
		return new ResponseEntity<List<Products>>(lproducts, HttpStatus.OK);
	}
	
	@GetMapping("/category/{categoryname}")
	ResponseEntity<List<Products>> getProductCategory(@PathVariable String categoryname) {
		List<Products> lproducts = pService.getProductsCategory(categoryname);
		System.out.println("PRODUCT CATEGORY SHOWED..........");
		return new ResponseEntity<List<Products>>(lproducts, HttpStatus.OK);
	}
	
	/*
	 * @GetMapping("/avgprice/{name}") ResponseEntity<Float>
	 * getAveragePrice(@PathVariable String name){ float avg =
	 * pService.getAveragePrice(name); return new ResponseEntity<Float>(avg,
	 * HttpStatus.OK); }
	 */


	@PostMapping("/add")
	ResponseEntity<Products> buyProducts(@RequestBody Products products) {
		
		if (products.getCategory() == null || products.getName()== null) {
			throw new InvalidNameException("Place Empty or null or doesnt Exist");
		}
		products = pService.bookProductsServ(products);
		System.out.println("PRODUCT SAVED..........");
		return new ResponseEntity<Products>(products, HttpStatus.CREATED);
	}

	
	@PutMapping("/update/{pid}")
	ResponseEntity<Products> update(@PathVariable("pid") Integer pid, @RequestBody Products products) {
		products = pService.updateProductsServ(pid, products);
		return new ResponseEntity<Products>(products, HttpStatus.CREATED);
	}

	
	@DeleteMapping("/buy/{pid}")
	ResponseEntity<Integer> buyItem(@PathVariable("pid") Integer productid) {
		Products products = pService.cancelProductRepo(productid);
		if (products == null) {
			throw new InvalidProductIDException("No such ticket  exists");
		}
		System.out.println("PRODUCT BOUGHT..........");
		return new ResponseEntity<Integer>(productid, HttpStatus.OK);
	}
}

