package com.ecom.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ecom.app.model.Products;
import com.ecom.app.repository.ProductRepository;

import jakarta.annotation.PostConstruct;



@Service
public class ProductService {
	// automatically adding code for DB interaction
	@Autowired
	private ProductRepository productRepo;
	// Dependency Injection => DI

	
	
	public Products getProductsServ(int productid) {
		Optional<Products> oproducts = productRepo.findById(productid);

		return oproducts.get();
	}

	public Products bookProductsServ(Products products) {
		return productRepo.save(products);
	}

	public List<Products> getProductsName(String pname){
		return productRepo.findByNameContaining(pname);
	}
	
	
	public List<Products> getProductsCategory(String categoryname){
		return productRepo.findByCategory(categoryname);
	}
	public Products updateProductsServ(int tid, Products products) {
		Products eProduct = productRepo.findById(tid).get();
		eProduct.setName(products.getName());
		eProduct.setCategory(products.getCategory());
		eProduct.setPrice(products.getPrice());
		eProduct.setSellingstatus(false);
		
		return productRepo.save(eProduct);
	}
	
	/*
	 * public Products updateProductsServ(int tid, Products products) { // Fetch the
	 * existing product by ID Products eProduct = productRepo.findById(tid)
	 * .orElseThrow(() -> new RuntimeException("Product with ID " + tid +
	 * " not found"));
	 * 
	 * // Update product details eProduct.setName(products.getName());
	 * eProduct.setCategory(products.getCategory());
	 * eProduct.setPrice(products.getPrice());
	 * 
	 * // Automatically set sellingstatus to false when updating
	 * eProduct.setSellingstatus(false);
	 * 
	 * // Save the updated product return productRepo.save(eProduct); }
	 */


	public Products cancelProductRepo(int productid) {
		Products products = productRepo.findById(productid).get();
		productRepo.deleteById(productid);
		return products;
	}

}

