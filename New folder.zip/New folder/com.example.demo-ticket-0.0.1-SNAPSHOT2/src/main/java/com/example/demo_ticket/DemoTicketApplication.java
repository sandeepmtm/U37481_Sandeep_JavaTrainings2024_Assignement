package com.example.demo_ticket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.example.demo_ticket.controller","com.example.demo_ticket", "com.example.demo_example.service","com.example.demo_ticket.model","com.example.demo_ticket.exception", "com.example.demo_ticket.repository" })
public class DemoTicketApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoTicketApplication.class, args);
	}

}
