package com.MockitoProj;

public interface UserRepository {
    User findById(Long id);
}