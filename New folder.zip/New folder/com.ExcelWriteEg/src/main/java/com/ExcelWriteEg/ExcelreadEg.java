package com.ExcelWriteEg;

import java.util.*;
import org.apache.poi.ss.usemodel.*;
import org.apache.poi.xssf.usemodel.*;

public class ExcelreadEg {
	public static void main(String[] args) throws Exception{
		Workbook wb = new XSSFWorkbook();
	}
}
