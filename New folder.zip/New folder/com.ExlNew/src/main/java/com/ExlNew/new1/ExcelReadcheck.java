package com.ExlNew.new1;
import java.io.*;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;



public class ExcelReadcheck{ 
	
public static void main(String[] args) throws Exception, FileNotFoundException,IllegalStateException, IOException {
// open file
FileInputStream fis = new FileInputStream("./exces.xlsx");

// read workbook
Workbook wbook = new XSSFWorkbook(fis);

System.out.println("No. of sheets: " + wbook.getNumberOfSheets());

int no_of_sheets = wbook.getNumberOfSheets();
double value = 0;

int no_of_rows = 0;
Sheet st = null;
for (int k = 0; k < no_of_sheets; k++) {
// read sheet
st = wbook.getSheetAt(k);

no_of_rows = st.getPhysicalNumberOfRows();

for (int i = 0; i < no_of_rows; i++) {
// read rows
Row row = st.getRow(i);

int no_of_cols = row.getLastCellNum();

for (int j = 0; j < no_of_cols; j++) {
// read cells
Cell cell = row.getCell(j);

value = value + cell.getNumericCellValue();
}
}
}
System.out.println("sum is "+value);

fis.close();

FileOutputStream fos = new FileOutputStream("./exces.xlsx");

Row row = st.createRow(0);
System.out.println("Created row..."+(0));
Cell cell = row.createCell(0);
cell.setCellValue(value);
wbook.write(fos);

Row row1 = st.getRow(0);
Cell cel2 = row1.getCell(1);
double val = cel2.getNumericCellValue();
val++;

System.out.println("First cell..."+val);
fos.close();
}
}

