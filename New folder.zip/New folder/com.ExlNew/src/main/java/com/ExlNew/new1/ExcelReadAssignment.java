package com.ExlNew.new1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadAssignment {

    public static void main(String[] args) throws Exception, FileNotFoundException, IllegalStateException, IOException {
        // Open file
        FileInputStream fis = new FileInputStream("./exces.xlsx");

        // Read workbook
        Workbook wbook = new XSSFWorkbook(fis);

        System.out.println("No. of sheets: " + wbook.getNumberOfSheets());

        // Access the first sheet (index 0)
        Sheet st = wbook.getSheetAt(0); // First sheet (Sheet 0)
        double value = 0;

        // Read rows and cells from the first sheet
        int no_of_rows = st.getPhysicalNumberOfRows();
        for (int i = 0; i < no_of_rows; i++) {
            // Read each row
            Row row = st.getRow(i);

            if (row != null) {
                int no_of_cols = row.getLastCellNum();
                for (int j = 0; j < no_of_cols; j++) {
                    // Read each cell
                    Cell cell = row.getCell(j);

                    // Check if the cell contains numeric data
                    if (cell != null && cell.getCellType() == CellType.NUMERIC) {
                        value += cell.getNumericCellValue();
                    }
                }
            }
        }

        System.out.println("Sum of numeric values: " + value);

        fis.close(); // Close input stream before writing

        // Write the sum into the first row and first cell of the first sheet
        Row firstRow = st.getRow(0);
        if (firstRow == null) {
            firstRow = st.createRow(0); // If the row doesn't exist, create it
        }
        Cell sumCell = firstRow.createCell(0); // First cell in the first row
        sumCell.setCellValue(value); // Write the sum of values into the cell

        // Write the updated Excel file back
        FileOutputStream fos = new FileOutputStream("./exces.xlsx");
        wbook.write(fos);

        // Increment value in the second cell of the first row (if it exists)
        Cell cellIncrement = firstRow.getCell(1); // Get second cell in the first row
        if (cellIncrement != null && cellIncrement.getCellType() == CellType.NUMERIC) {
            double incrementedValue = cellIncrement.getNumericCellValue() + 1;
            cellIncrement.setCellValue(incrementedValue); // Increment value
            System.out.println("Incremented value in second cell: " + incrementedValue);
        } else {
            System.out.println("Second cell is not numeric or does not exist.");
        }

        // Close output stream and workbook
        fos.close();
        wbook.close();
    }
}
