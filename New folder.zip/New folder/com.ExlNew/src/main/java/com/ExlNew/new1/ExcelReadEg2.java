package com.ExlNew.new1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadEg2 {
    public static void main(String[] args) {
        String filePath = "./exces.xlsx"; // Path to the original Excel file

        // Open input file stream
        try (FileInputStream fis = new FileInputStream(filePath)) {

            // Read the workbook
            Workbook wbook = new XSSFWorkbook(fis);

            // Get the first sheet ("Sheet1")
            Sheet sheet = wbook.getSheetAt(0);

            // Track the number of rows in the sheet
            int no_of_rows = sheet.getPhysicalNumberOfRows();

            // Iterate through all rows in the current sheet
            for (int i = 0; i < no_of_rows; i++) {
                Row row = sheet.getRow(i);

                if (row != null) {
                    int no_of_cols = row.getLastCellNum(); // Get the last column in the row

                    // Iterate through all columns in the current row
                    for (int j = 0; j < no_of_cols; j++) {
                        Cell cell = row.getCell(j);

                        // If the cell contains a numeric value
                        if (cell != null && cell.getCellType() == CellType.NUMERIC) {
                            double value = cell.getNumericCellValue();

                            // Write the same value in the next column (next empty column)
                            Cell newCell = row.createCell(no_of_cols); // Create a cell in the next column
                            newCell.setCellValue(value);
                        }
                    }
                }
            }

           
            try (FileOutputStream fos = new FileOutputStream(filePath)) {
                wbook.write(fos); // Overwrite the original Excel file with the updated content
                System.out.println("Updated workbook with numeric values written to the same file: 'exces.xlsx'.");
            }

            // Close the workbook
            wbook.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
