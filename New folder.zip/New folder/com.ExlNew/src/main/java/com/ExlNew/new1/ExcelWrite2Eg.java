package com.ExlNew.new1;

import java.io.File;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelWrite2Eg {
	
	static String arr[][] = {{"abc", "def", "ghi"}, {"jkl", "nmo", "pqr"}, {"xyz", "uvw", "str"}};
	public static void main(String[] args) {
		try {
		//create workbook
				Workbook wbook = new XSSFWorkbook();

				//create a new sheet
				Sheet st = wbook.createSheet("First Sheet");
				
		for (int i = 0; i < arr.length; ++i) {
			//create row in excel
			//create row
			Row row = st.createRow(i);
            for (int j = 0; j < arr[0].length; j++) {
            	//create cell in excel
            	Cell cell = row.createCell(j);
            	cell.setCellValue(arr[i][j] );
                System.out.print("array values are " +arr[i][j] + "\t");
            }//closing inner loop
            System.out.println("......");
		}
            
		
		FileOutputStream fos = new FileOutputStream("./rowcolexcel1.xlsx");
		File file = new File("file/path");
		String parentPath = file.getAbsoluteFile().getParent();
		String relPath = file.getAbsoluteFile().getPath();
		System.out.println("......"+relPath);
		wbook.write(fos);
		fos.close();
		wbook.close();
		
		}
		
		catch (Exception e){
			e.printStackTrace();
			
		}
			
		
		}
	
	}

