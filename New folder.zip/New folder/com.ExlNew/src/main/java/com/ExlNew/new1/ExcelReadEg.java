package com.ExlNew.new1;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadEg {
	public static void main(String[] args) throws Exception{
		//read file
		FileInputStream fos = new FileInputStream("./rowcolexcel1.xlsx");
		//read workbook
		Workbook wbook = new XSSFWorkbook(fos);
		
		
		   // Get the number of rows
        
   //     System.out.println("Number of rows: " + numberOfRows);
		
		System.out.println("No of sheets...... "+wbook.getNumberOfSheets());
		
		//get number sheets in Excel
		int noofSheets = wbook.getNumberOfSheets();
		 System.out.println("Number of rows: " + noofSheets);
		 
		for (int k=0; k<noofSheets;++k) {
			//read sheet
			Sheet st = wbook.getSheetAt(k);
			int numberOfRows = st.getPhysicalNumberOfRows();
	        
		for (int i =0; i<numberOfRows; i++ ) {
			Row row = st.getRow(i);
			int noofCol = row.getLastCellNum();
			for (int j=0; j<noofCol;j++) {
				Cell cell = row.getCell(j);
				System.out.println("values of cells in sheets...... "+cell.toString());
		}
		}
		

		
		
		//read cell
		
		
		
		wbook.close();
		fos.close();
			}
			

	}}
