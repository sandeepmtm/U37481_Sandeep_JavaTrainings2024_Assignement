package com.service.ecommpackage;
import com.data.ecommpackage.DBDataFetch;
import com.data.ecommpackage.Product;


//DB Is ConsoleApp and Table is Products
public class InventoryService implements InventoryServiceInterface {
	private  DBDataFetch dbproddata;
	
//Constructor
	public InventoryService(DBDataFetch dbproddata) {
		this.dbproddata=dbproddata;
	}
	
	
	
//Method to search for a product by name and display its details
		@Override
		public void searchProductByName(String name) {
	//	System.out.println("InventoryServiceInterface search call is working");
		Product product=dbproddata.searchProductByName(name);
		if(product!=null) {
			System.out.println("Product found. ProductID: " + product.getProduct_id()+ ", ProductName: "+ product.getProduct_name()+", " + "Categories: " + product.getProduct_category() + "and   Price: " + product.getPrice());
		
		}
		else {
			System.out.println("Product not found");

		}
	}
//Method to get a product by its id
		
		@Override
		public Product  getProductById(int id) {
			return dbproddata.getProductById(id);
			
		}
	}
