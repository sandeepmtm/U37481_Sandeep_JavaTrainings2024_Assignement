package com.service.ecommpackage;
import com.data.ecommpackage.Product;
import com.data.ecommpackage.ShoppingCart;

public  class ShoppingCartService implements ShoppingCartServiceInterface{
	private ShoppingCart shopcart=new ShoppingCart();
    private InventoryServiceInterface inventoryserviceinterface;

    
    //inject Inventory service instance here
    public ShoppingCartService(InventoryServiceInterface inventoryserviceinterface) {
    	this. inventoryserviceinterface= inventoryserviceinterface;
    }
    
    
    
//method to add a product to the cart
    @Override
    public void addProductToCart(int id,int quantity) {
	Product product=inventoryserviceinterface.getProductById(id);
	if(product!=null) {
		shopcart.addProductsToShoppingCart(product,quantity);
		System.out.println("Product added to Cart");
	}
		else {
			System.out.println("Product not found");
		}
	}
	
	
//Method to view items in Cart
    @Override
	public void viewCart() {
	shopcart.viewShoppingCart();
}



//Method to checkout items in Cart
    @Override
	public void checkOut() {
	shopcart.checkoutShoppingCart();
}


}
