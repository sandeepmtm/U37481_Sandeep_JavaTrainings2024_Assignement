package com.service.ecommpackage;

public interface ShoppingCartServiceInterface {

	void viewCart();
	void checkOut();
	void addProductToCart(int id, int quantity);
}
