package com.app.ecommpackage;
import com.data.ecommpackage.DBDataFetch;
import com.service.ecommpackage.InventoryService;
import com.service.ecommpackage.InventoryServiceInterface;
import com.service.ecommpackage.ShoppingCartService;
import com.service.ecommpackage.ShoppingCartServiceInterface;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Scanner;

	public class EcommerceApp {
	private  InventoryServiceInterface inventoryserviceinterface;
	private ShoppingCartServiceInterface shoppingcartserviceinterface;
    private Scanner scanner=new Scanner(System.in);
    
    //Constructor
    public EcommerceApp(InventoryServiceInterface inventoryserviceinterface,ShoppingCartServiceInterface shoppingcartserviceinterface) {
    	this.inventoryserviceinterface=inventoryserviceinterface;
    	this.shoppingcartserviceinterface=shoppingcartserviceinterface;
    }
    
    
	public static void main(String args[]) {
	try {

//Setup Database Connection
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection  connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/ConsoleApp","root", "pass@word1");
//Create the Data Layer
		DBDataFetch dbproddata=new DBDataFetch(connection);
//Create the Service Layer
		InventoryService inventoryservice=new InventoryService(dbproddata);
		ShoppingCartService shoppingcartservice= new ShoppingCartService(inventoryservice);
//Initialize the App Layer
		EcommerceApp app=new EcommerceApp(inventoryservice,shoppingcartservice);
//Run the application
		app.run();
	}catch(Exception e) {
		e.printStackTrace();
	}
	}
	
// Method to run Application
	public void run() {
		
		while(true) {
			displayMenu();
			int choice=scanner.nextInt();
//consume new line
			scanner.nextLine();
			
			switch(choice) {
			
			case 1:searchProduct();
			break;
			case 2:addProductToCart();
			break;
			case 3:shoppingcartserviceinterface.viewCart();
			break;
			case 4:shoppingcartserviceinterface.checkOut();
			break;
			case 5:System.out.println("Exit from Console App");
			return;
			default:
			System.out.println("Invalid choice.Please try again.");

				
			}
		}
	}

//Method to display MenuList
	private void displayMenu() {
		System.out.println("Menu: ");
		System.out.println("1. Search for a Product");
		System.out.println("2. Add a Product to the cart");
		System.out.println("3. View Shopping Cart");
		System.out.println("4. Checkout");
		System.out.println("5. Exit");
		System.out.println("Enter your Choice");
	}

//Method to search Product
	private void searchProduct() {
		System.out.println("Enter Product name: ");
		String name=scanner.nextLine();
		inventoryserviceinterface.searchProductByName(name);
	//	System.out.println("App layer search method is working");

		
	}

//Method to add product to cart
	public void addProductToCart() {
		System.out.println("Enter Product id: ");
		int id=scanner.nextInt();
		System.out.println("Enter Quantity: ");
		int quantity=scanner.nextInt();
		shoppingcartserviceinterface.addProductToCart(id, quantity);
	}

	}
