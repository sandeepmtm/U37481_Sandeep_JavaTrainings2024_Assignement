package com.example.demo_resttemplate;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MainTestApp {
	public static void main(String[] args)  throws InterruptedException
	{ 
	try {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
			
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
			
		driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.pom.selenium\\src\\main\\resources\\Home.html");
		
		
		//create homepage instance	
		HomePage homePage = new HomePage(driver);
		
		
		// on homepage, click about page
		Thread.sleep(3000);
		
		// going to about page
		AboutPage aboutPage = homePage.gotoAboutPage();
		Thread.sleep(3000);
		// clicking more info button
		aboutPage.moreInfoButton();
		Thread.sleep(2000);
		
		//reading message after clicking more info button
		aboutPage.moreInfoButtonMessage();
		Thread.sleep(3000);
	
		//goig to contact page
		ContactPage contactPage = homePage.gotoContactPage();
		
		
		//adding details
		Thread.sleep(3000);
		contactPage.fillContactPage("sandeep", "sandeep.m@ust.com", "Welcome");
		Thread.sleep(3000);
		// submitting contact details
		contactPage.checkSubmission();
		Thread.sleep(3000);
		
		//on contact page, go to home page
		contactPage.gotoHomePage();
		
		Thread.sleep(3000);
		
		driver.quit();
		
	} catch (Exception e) {
		e.printStackTrace();
		}
	
	}
}
