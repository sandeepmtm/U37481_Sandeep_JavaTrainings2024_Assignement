package com.example.demo_resttemplate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AboutPage {
	
	//these are data members in this class
		private WebDriver driver;
		//create locators
		private By homeLink = By.id("homeLink");
		private By contactLink = By.id("contactLink");
		private By moreInfoButton = By.id("moreInfoButton");
		private By moreInfo = By.id("moreInfo");
		
		
		//constructor as data member
		public AboutPage (WebDriver driver) {
			System.out.println("About page displayed............"+driver.getTitle());
			 this.driver = driver;
		}
		
		//method to perform actions on above elements
		public HomePage gotoHomePage() {
			WebElement homeLinkElement = driver.findElement(homeLink);
			homeLinkElement.click();
			return new HomePage(driver);
		}
		//method to perform actions on above elements
				public ContactPage gotoContactPage() {
					WebElement aboutContactElement = driver.findElement(contactLink);
					aboutContactElement.click();
					return new ContactPage(driver);
				}
		
				//click MoreInfo button
				public void moreInfoButton() {
					WebElement clickMoreInfoButton = driver.findElement(moreInfoButton);
					clickMoreInfoButton.click();
				}

				// print message after clicking MoreInfo button
				public void moreInfoButtonMessage() {
					System.out.println("Message displayed after clicking More Info button............"+driver.findElement(moreInfo).getText());;
				}
}
