package com.example.demo_resttemplate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ContactPage {
	
	//these are data members in this class
			private WebDriver driver;
			//create locators
			private By homeLink = By.id("homeLink");
			private By aboutLink = By.id("aboutLink");
			private By nameField = By.id("name");
			private By emailField = By.id("email");
			private By messageField = By.id("message");
			private By submitButtonElement = By.id("submitButton");
			private By feedbackMessage = By.id("feedbackMessage");
			
			//constructor as data member
			public ContactPage (WebDriver driver) {
				System.out.println("Contact page displayed............"+driver.getTitle());
				 this.driver = driver;
			}
			
			public HomePage gotoHomePage() {
				WebElement homeLinkElement = driver.findElement(homeLink);
				homeLinkElement.click();
				return new HomePage(driver);
			}
			
			//method to perform actions on above elements
			public AboutPage gotoAboutPage() {
				WebElement aboutLinkElement = driver.findElement(aboutLink);
				aboutLinkElement.click();
				return new AboutPage(driver);
			}
						
			//method to perform actions on above elements
			public ContactPage fillContactPage(String name, String email, String message) {
				driver.findElement(nameField).sendKeys(name);
				driver.findElement(emailField).sendKeys(email);
				driver.findElement(messageField).sendKeys(message);
				driver.findElement(submitButtonElement).click();
				
				return new ContactPage(driver);
			}
			
			public String checkSubmission() {
				String message = driver.findElement(feedbackMessage).getText();
				System.out.println("Submitted text message:  "+message);
				return message;
				
			}
}
