package com.JUnitTest;

import java.util.Objects;

public class Applicant {
	private String name;
	private int age;
	float loan_eligibility;
	public Applicant(String name, int age, float loan_eligibility) {
		super();
		this.name = name;
		this.age = age;
		this.loan_eligibility = loan_eligibility;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}
	/**
	 * @return the loan_eligibility
	 */
	public float getLoan_eligibility() {
		return loan_eligibility;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}
	/**
	 * @param loan_eligibility the loan_eligibility to set
	 */
	public void setLoan_eligibility(float loan_eligibility) {
		this.loan_eligibility = loan_eligibility;
	}
	
	public Applicant addEligibility (float percent) {
	float multiplier = 1 + (percent*0.01f);
	loan_eligibility = loan_eligibility * multiplier;
	
	return this;
	}
	@Override
	public int hashCode() {
		return Objects.hash(age, loan_eligibility, name);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Applicant other = (Applicant) obj;
		return age == other.age
				&& Float.floatToIntBits(loan_eligibility) == Float.floatToIntBits(other.loan_eligibility)
				&& Objects.equals(name, other.name);
	}
	
}
