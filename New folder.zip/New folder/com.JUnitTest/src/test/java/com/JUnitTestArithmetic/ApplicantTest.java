package com.JUnitTestArithmetic;

import org.junit.jupiter.api.Test;

import com.JUnitTest.Applicant;
import com.JUnitTest.Arithemetic;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

public class ApplicantTest {
	
	private Applicant applicant ;
	
	
	@BeforeEach
	void eligApplicant()
	{
		applicant = new Applicant ("name", 40, 10000);
	}
	@Test
	void testElig() {
		Applicant  applicant_actual = applicant.addEligibility(10);
		//assert expected
		assertEquals (11000, applicant_actual.getLoan_eligibility(), "Checking loan eligibility after incrementing 10 percent");
	
		Applicant applicant_expected =  new Applicant ("name", 40, 11000);
		assertEquals (applicant_actual, applicant_expected, "Directly checking the objects after incrementing");
		
	}
	
	

}
