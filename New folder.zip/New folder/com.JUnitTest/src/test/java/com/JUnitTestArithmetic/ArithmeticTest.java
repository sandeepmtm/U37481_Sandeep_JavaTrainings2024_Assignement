package com.JUnitTestArithmetic;

import org.junit.jupiter.api.Test;

import com.JUnitTest.Arithemetic;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

class ArithmeticTest {

    private final Arithemetic arithmetic = new Arithemetic();

    @BeforeAll // execute only once that to before all test cases
    static void befallmet() {
    System.out.println("Before All method.......");
    }
    
    @BeforeEach
    void befeachmet() {    	
    System.out.println("Before Each method--------");
    }
    
    
    @Test
    void testAdd() {
        assertEquals(5, arithmetic.add(2, 3), "Addition should return the sum of two numbers");
        System.out.println("Test-1.......");
    }
    
    @Test
    void testAddNegNum() {
    	Arithemetic arith = new Arithemetic();
    	int result = arith.add(-2, -3);
    	assertEquals(-5, result, "Addition possible for negative numbers" );
    	 System.out.println("Test-2.......");
    }

    @Test
    void testSubtract() {
        assertEquals(1, arithmetic.subtract(5, 4), "Subtraction should return the difference of two numbers");
        System.out.println("Test-3.......");
    }

    @Test
    void testMultiply() {
        assertEquals(6, arithmetic.multiply(2, 3), "Multiplication should return the product of two numbers");
        System.out.println("Test-4.......");
    }
    
    

    @Test
    void testDivide() {
        assertEquals(2, arithmetic.divide(6, 3), "Division should return the quotient of two numbers");
        System.out.println("Test-5.......");
    }
    
    @Test
    void testMax() {
        assertEquals(10.01, arithmetic.max(10.01, 10.001), "Max value of given two numbers");
        System.out.println("Test-6.......");
    }

    @Test
    void negtestMax() {
        assertEquals(-0.01, arithmetic.max(-0.01, -10.01), "Max value of given two numbers");
        System.out.println("Test-7.......");
    }
    
    @Test
    void testDivideByZero() {
        ArithmeticException thrown = assertThrows(ArithmeticException.class, () -> arithmetic.divide(1, 0), "Division by zero should throw ArithmeticException");
        assertEquals("Cannot divide by zero", thrown.getMessage());
        System.out.println("Test-8.......");
    }
}
