package com.example.productpagin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Page;
import com.example.productpagin.model.Product;

public interface ProductRepository extends JpaRepository<Product, Long>{
	//Page<Product>findByName(int id, Pageable pageable);
//	Page<Product>findByNameContaining(int id, Pageable pageable);

	Page<Product> findByNameContaining(String string, Pageable pageable);
// use findByNameStartWith findByNameContaining
 
}