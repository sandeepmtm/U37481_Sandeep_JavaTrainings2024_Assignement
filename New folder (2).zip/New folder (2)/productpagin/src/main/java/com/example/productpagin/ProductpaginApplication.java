package com.example.productpagin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;


@SpringBootApplication(scanBasePackages = "com.example.productpagin")
@EntityScan(basePackages = "com.example.productpagin.model")
public class ProductpaginApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductpaginApplication.class, args);
	}

}
