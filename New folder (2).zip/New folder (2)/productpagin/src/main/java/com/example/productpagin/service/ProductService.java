package com.example.productpagin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.productpagin.model.Product;
import com.example.productpagin.repository.ProductRepository;

import jakarta.annotation.PostConstruct;

@Service
public class ProductService {

    @Autowired
    private ProductRepository pRepo;

    public Page<Product> getProducts(int page, int size, String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).descending());
        return pRepo.findAll(pageable);
    }

    public Product createProduct(Product prod) {
        return pRepo.save(prod);
    }
    
    @PostConstruct
    void met() {
    	 Pageable pageable = PageRequest.of(1, 2, Sort.by("price").descending());
   // 	 Page <Product> pprod = pRepo.findByName(1, pageable);
   	 Page <Product>  pprod1 = pRepo.findByNameContaining("user1", pageable);
   	 //iterate product
    	 pprod1.forEach(System.out::println); 
    	 //:: println method reference. method handle (not calling method) to pass reference to call
    }
}
