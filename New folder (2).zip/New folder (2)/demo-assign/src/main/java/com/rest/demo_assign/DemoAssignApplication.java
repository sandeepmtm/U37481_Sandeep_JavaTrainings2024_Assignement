package com.rest.demo_assign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoAssignApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoAssignApplication.class, args);
	}

}
