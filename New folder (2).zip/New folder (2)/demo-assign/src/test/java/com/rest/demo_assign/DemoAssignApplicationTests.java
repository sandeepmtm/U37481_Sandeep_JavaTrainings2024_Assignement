package com.rest.demo_assign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoAssignApplicationTests {

	@Test
	void contextLoads() {
	}

}
