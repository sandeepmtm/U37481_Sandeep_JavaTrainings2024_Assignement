


package com.pom.selenium;

import java.time.Duration;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.junit.jupiter.api.Assertions.*;

public class MainTestAppJUnit {
    private static WebDriver driver;  // This is the class-level static variable
    private static WebDriverWait wait;
    
    @BeforeAll
    public static void setUp() throws Exception {
        // Set up the path to your WebDriver executable (chromedriver)
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");   
        
        // Initialize the class-level 'driver' variable (not a new local variable)
        driver = new ChromeDriver();  // Assign to the class-level driver
        
        // Initialize the WebDriverWait object for handling waits
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @Test
    public void testNavigateHomeToAbout() {
        // Use the driver to navigate to your local HTML page
        driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.pom.selenium\\src\\main\\resources\\Home.html");
        
        // Create HomePage instance
        HomePage homePage = new HomePage(driver);
        
        // Navigate to the About page
        AboutPage aboutPage = homePage.gotoAboutPage();
        
        // Wait until the title of the About page contains "About"
        wait.until(ExpectedConditions.titleContains("About"));
        
        // Assert that the title of the page contains "About"
        assertTrue(driver.getTitle().contains("About"));
    }
    
    @Test
    public void testNavigateHomeToContact() {
        // Use the driver to navigate to your local HTML page
        driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.pom.selenium\\src\\main\\resources\\Home.html");
        
        // Create HomePage instance
        HomePage homePage = new HomePage(driver);
        
        // Navigate to the About page
       ContactPage contactPage = homePage.gotoContactPage();
        
        // Wait until the title of the About page contains "About"
        wait.until(ExpectedConditions.titleContains("Contact"));
        
        // Assert that the title of the page contains "About"
        assertTrue(driver.getTitle().contains("Contact"));
    }
    
    
    // go to Home page and then About page and then Contact page
    @Test
    public void testNavigateHomeToAboutThenContact() {
        // Use the driver to navigate to your local HTML page
        driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.pom.selenium\\src\\main\\resources\\Home.html");
        
     // Create HomePage instance
        HomePage homePage = new HomePage(driver);
        
        // Navigate to the About page
        AboutPage aboutPage = homePage.gotoAboutPage();
        
        // Wait until the title of the About page contains "About"
        wait.until(ExpectedConditions.titleContains("About"));
        
        // Assert that the title of the page contains "About"
        assertTrue(driver.getTitle().contains("About"));
      
     
       ContactPage contactPage = aboutPage.gotoContactPage();
        
        // Wait until the title of the About page contains "About"
        wait.until(ExpectedConditions.titleContains("Contact"));
        
        // Assert that the title of the page contains "About"
        assertTrue(driver.getTitle().contains("Contact"));
    }
    
    @Test
    public void testNavigateHomeToContactSubmission() throws InterruptedException {
        // Use the driver to navigate to your local HTML page
        driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.pom.selenium\\src\\main\\resources\\Home.html");
        
        // Create HomePage instance
        HomePage homePage = new HomePage(driver);
        
        // Navigate to the About page
       ContactPage contactPage = homePage.gotoContactPage();
        
        // Wait until the title of the About page contains "About"
        wait.until(ExpectedConditions.titleContains("Contact"));
        
        contactPage.fillContactPage("sandeep", "sandeep.m@ust.com", "Welcome");
		Thread.sleep(6000);
		// submitting contact details
		String message = contactPage.checkSubmission();
		// Assert that the title of the message contains 
        assertTrue(message.contentEquals("Thank you for your message! We will get back to you soon."));
    
    }
    
    
    @AfterAll
    public static void tearDown() {
    	if (driver != null) {
    	driver.quit();
    	}
    }
}
