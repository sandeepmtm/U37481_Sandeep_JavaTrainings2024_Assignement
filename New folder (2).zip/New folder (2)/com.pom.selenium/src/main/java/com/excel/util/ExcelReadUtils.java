package com.excel.util;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.junit.jupiter.params.provider.Arguments;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelReadUtils {
	//open excel file, workbook, sheet
	private static Workbook workbook;
	private static Sheet sheet;
	public static void init() {
		
		{
			try {
				//open test input data from excel file
				
				FileInputStream fis = new FileInputStream("D:\\Softwares\\Selenium_TestData.xlsx");
			//	FileInputStream fis = new FileInputStream("./Selenium_TestData.xlx");
				//create workbook
				workbook = new XSSFWorkbook(fis);
				//go to first sheet 
				sheet = workbook.getSheetAt(0);

				
			} catch (Exception e) {
				e.printStackTrace();
			}
	}
	
	
	//Read test data from contact form
		
	}
	public static Stream<Arguments>readContactFormData() {
		List<Arguments> args = new ArrayList<>();
		
		Row row = sheet.getRow(0);
		Cell cell = row.getCell(0);
		int no_of_test_rows = (int)cell.getNumericCellValue();
		
		for (int i=1; i<(no_of_test_rows+1);i++) {
			row = sheet.getRow(i);
			
			Cell tcase_id_cell = row.getCell(0);
			String testCaseId = tcase_id_cell.getStringCellValue();
			
			Cell name_cell = row.getCell(1);
			String name = name_cell.getStringCellValue();
			
			Cell email_cell = row.getCell(2);
			String email = email_cell.getStringCellValue();
			
			Cell message_cell = row.getCell(3);
			String details = message_cell.getStringCellValue();
			
			args.add(Arguments.of(testCaseId,name,email,details));	
			
		}
		return args.stream();
	}
	
}
	


