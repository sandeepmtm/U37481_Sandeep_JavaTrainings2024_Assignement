package com.example.demo_ticket.repository;

import java.util.HashMap;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo_ticket.model.Ticket;

@Repository
public interface TicketRepository extends JpaRepository<Ticket, Integer> {
	/* Get all Tickets with a specific From Place and To Place */
//Derived Query method
	public List<Ticket> findByFromplaceOrToplace(String from_place, String to_place);

	/* Get all Tickets From Place and to Place , Price less than */
	public List<Ticket> findByFromplaceAndToplaceAndPriceLessThan(String from_place, String to_place, float price);

	// JPQL
	@Query("SELECT w FROM Ticket w WHERE w.fromplace = :fromplace")
	List<Ticket> met(@Param("fromplace") String str);
	
	@Query(value = "SELECT * FROM Ticket WHERE username = :username", nativeQuery =
			  true) List<Ticket> met9(@Param("username") String username);
	
	 @Modifying
	 @Transactional
	 @Query("UPDATE Ticket p SET p.price = p.price*0.9 WHERE p.username = :username")
	 void met10(@Param("username")String username);	

}
