package com.example.demo_ticket.model;


import java.util.Date;



import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

@Entity
public class Ticket {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	
	@NotNull(message="user name cannot be blank")

	@Column
	private String username;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Ticket [id= "+id+ ", username= "+ username + ", price= " +price+", From= " +fromplace+", To= " +toplace+", email= " +email+", mobile=" +mobileno+"]";
	}

	@Column
	@NonNull
	private String fromplace;
	
	@Column
	@NonNull
	private String toplace;
	
	@Column
	@DecimalMin("99.9")
	@DecimalMax("100000")
	private float price;
	
	//@Past
	@Column
	@Future(message = "Future date only")
	private Date traveldate;

	@Column
	@NonNull
	@Email
	private String email;
	
	@Column
	@Pattern(regexp="^[1-9]{1}[0-9]{10}$")
	private String mobileno;
	
	@Column
	@Pattern(regexp= "^.{1,10}$")
	private String noofseats;

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	
	
	/**
	 * @return the noofseats
	 */
	public String getNoofseats() {
		return noofseats;
	}



	/**
	 * @param noofseats the noofseats to set
	 */
	public void setNoofseats(String noofseats) {
		this.noofseats = noofseats;
	}



	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	
	/**
	 * @return the mobileno
	 */
	public String getMobileno() {
		return mobileno;
	}

	/**
	 * @param mobileno the mobileno to set
	 */
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public Ticket() {}
	
	public Ticket(int id, @NotNull(message="user name cannot be blank") @NonNull String from_place, @NonNull String to_place, float price, String username, @Email String email, Date traveldate, @NonNull String mobileno, @NotNull String noofseats ) {
		super();
		this.id = id;
		this.fromplace = from_place;
		this.toplace = to_place;
		this.price = price;
		this.username = username;
		this.email = email;
		this.traveldate = traveldate;
		this.mobileno = mobileno;
		this.noofseats = noofseats;
	}

	

	/**
	 * @return the traveldate
	 */
	public Date getTraveldate() {
		return traveldate;
	}

	/**
	 * @param traveldate the traveldate to set
	 */
	public void setTraveldate(Date traveldate) {
		this.traveldate = traveldate;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	public String getFromplace() {
		return fromplace;
	}

	public void setFromplace(String fromplace) {
		this.fromplace = fromplace;
	}

	public String getToplace() {
		return toplace;
	}

	public void setToplace(String toplace) {
		this.toplace = toplace;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	

}
