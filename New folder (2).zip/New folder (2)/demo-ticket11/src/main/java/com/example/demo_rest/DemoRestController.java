package com.example.demo_rest;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoRestController {
	
	@GetMapping("/test")
	String  meth() {
		System.out.println("-- rest controller successful...");	
	return "...confirm that user REST controller working..";
	}	
	
	@GetMapping("/ticket")
	//127.0.0.1:8085/ticket?tid=6453
	Ticket getTicket(@RequestParam("tid")int ticket_id) {
		
	return new Ticket ("Hello-Worlds", ticket_id, "address", 10);
	}
	
	@PostMapping("/bookticket")
	Ticket bookTicket(@RequestBody Ticket ticket) {
		System.out.println("booking successful..."+ticket);	
		ticket.setId(108);
		ticket.setNo_of_tickets(4);
	return ticket;
	}
	
	@DeleteMapping("/cancel")
	String cancelTicket(@RequestParam("tid")int ticket_id) {
		return "cancel successful..."+ticket_id+ "----";	
		
	
	}
}


	