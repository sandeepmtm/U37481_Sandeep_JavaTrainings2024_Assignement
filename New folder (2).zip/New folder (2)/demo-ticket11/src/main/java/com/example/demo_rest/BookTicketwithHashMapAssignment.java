package com.example.demo_rest;

import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

@RestController
public class BookTicketwithHashMapAssignment {

    // A map to store booked tickets where the key is ticket ID and value is the Ticket object
    private Map<Integer, Ticket> bookedTickets = new HashMap<>();

    @GetMapping("/test")
    String meth() {
        System.out.println("-- rest controller successful...");
        return "...confirm that user REST controller working..";
    }

    @GetMapping("/ticket")
    //127.0.0.1:8085/ticket?tid=6453
    Ticket getTicket(@RequestParam("tid") int ticket_id) {
        return new Ticket("Hello-Worlds", ticket_id, "address", 10);
    }

    @PostMapping("/bookticket")
    Ticket bookTicket(@RequestBody Ticket ticket) {
        System.out.println("booking successful... " + ticket);
        // Generate a new ticket ID and store it in the map
        int newId = bookedTickets.size() + 1; // Generate a new ticket ID based on the current size
        ticket.setId(newId);
        ticket.setNo_of_tickets(4);
        bookedTickets.put(newId, ticket); // Add the ticket to the map with the new ID as the key
        return ticket;
    }

    @DeleteMapping("/cancel")
    String cancelTicket(@RequestParam("tid") int ticket_id) {
        Ticket removedTicket = bookedTickets.remove(ticket_id); // Remove the ticket by its ID
        if (removedTicket != null) {
            return "Cancel successful... Ticket ID: " + ticket_id;
        } else {
            return "Ticket ID not found: " + ticket_id;
        }
    }

    @GetMapping("/allbookedtickets")
    Map<Integer, Ticket> getAllBookedTickets() {
        return bookedTickets; // Return all booked tickets in the form of a map
    }
}
