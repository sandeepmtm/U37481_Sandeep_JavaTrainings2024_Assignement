package com.example.demo_rest;

public class Ticket {
	private String name;
	private int Id;
	private String address;
	private int no_of_tickets;
	public Ticket(String name, int id, String address, int no_of_tickets) {
		super();
		this.name = name;
		Id = id;
		this.address = address;
		this.no_of_tickets = no_of_tickets;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return Id;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		Id = id;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the no_of_tickets
	 */
	public int getNo_of_tickets() {
		return no_of_tickets;
	}
	/**
	 * @param no_of_tickets the no_of_tickets to set
	 */
	public void setNo_of_tickets(int no_of_tickets) {
		this.no_of_tickets = no_of_tickets;
	}
	
	

}
