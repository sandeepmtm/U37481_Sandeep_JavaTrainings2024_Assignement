package com.example.demo_rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/tkts/")
public class MoreRestControllerDemo {
	
	@GetMapping("/test")
	
	  String  meth() {
		System.out.println("user rest controller successful...");	
		return "confirm that user REST controller working";
	}
	
	@DeleteMapping("/cancelbooking/{ticket_id}")
	//http://localhost:8080/tkts/cancelbooking/5678
	ResponseEntity <String>  cancelBooking(@PathVariable int ticket_id) {
		String str = "cancel successful..."+ticket_id+ "----";	
		return new ResponseEntity<String> (str, HttpStatus.OK);
	}
	
	@DeleteMapping("/cancelbookings/{ticket_id}/ticket")
	//http://localhost:8080/tkts/cancelbooking/5678
	ResponseEntity <String>  cancelBookings(@PathVariable("ticket_id") int tid) {
		String str = "cancel successful..."+tid+ "----";	
		return new ResponseEntity<String> (str, HttpStatus.OK);
	}
	
}
