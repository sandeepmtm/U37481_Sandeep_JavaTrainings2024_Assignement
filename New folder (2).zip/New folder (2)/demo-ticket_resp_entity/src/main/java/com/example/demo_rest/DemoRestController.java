package com.example.demo_rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/tkt")
public class DemoRestController {
	
	@GetMapping("/test")
	String  meth() {
		System.out.println("-- rest controller successful...");	
	return "...confirm that user REST controller working..";
	}	
	
	@GetMapping("/ticket")
	//127.0.0.1:8085/ticket?tid=6453
	ResponseEntity <Ticket> getTicket(@RequestParam("tid")int ticket_id) {
		// get ticket with tid ticket Id from collection
	Ticket ticket = new Ticket ("Hello-Worlds", ticket_id, "address", 108);
	ResponseEntity<Ticket> entity = new ResponseEntity<>(ticket, HttpStatus.OK);
	return entity ;
	}
	
	@PostMapping("/bookticket")
	ResponseEntity <Ticket>bookTicket(@RequestBody Ticket ticket) {
		// RequestBody creates Java object from request
		System.out.println("booking successful..."+ticket);	
		ticket.setId(108);
		ticket.setNo_of_tickets(4);
		ResponseEntity<Ticket> entity = new ResponseEntity<>(ticket, HttpStatus.CREATED );
		return entity;
	}
	
	
	
	@DeleteMapping("/cancel")
	String cancelTicket(@RequestParam("tid")int ticket_id) {
		return "cancel successful..."+ticket_id+ "----";			
	}
}


	