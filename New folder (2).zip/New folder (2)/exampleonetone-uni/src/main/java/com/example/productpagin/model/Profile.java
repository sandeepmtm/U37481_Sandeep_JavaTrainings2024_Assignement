package com.example.productpagin.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class Profile {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
private long id;
	@Column
private String bio;
	
	
/*
 * @JoinColumn(name= "user_id")
 * 
 * @OneToOne
 * 
 * @JsonIgnore private User user;
 */
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @return the bio
	 */
	public String getBio() {
		return bio;
	}

	/**
	 * @return the user
	 */
	/*
	 * public User getUser() { return user; }
	 */

	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @param bio the bio to set
	 */
	public void setBio(String bio) {
		this.bio = bio;
	}

	/**
	 * @param user the user to set
	 */
	/*
	 * public void setUser(User user) { this.user = user; }
	 */
	private Profile getProfile() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String toString() {
		return "Profile [id=" + id + ", bio=" + bio + ", ]";
	}
	
	
}
