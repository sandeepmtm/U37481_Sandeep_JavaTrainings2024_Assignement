package com.example.productpagin.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.productpagin.repository.UserRepository;
import com.example.productpagin.model.Profile;
import com.example.productpagin.model.User;

@Service
public class UserService {
	@Autowired
	private UserRepository uRepo;

	public User createUser(User user) {
		Profile prof = user.getProfile();
	//	prof.setUser(user);
		return uRepo.save(user);
	}

	public User getUser(long userid) {
		User user = null;
		Optional<User> ouser = uRepo.findById(userid);
		if(ouser.isPresent()) {
			user= ouser.get();
		}
		return user;
	}
	
	public User updateUser(long userid, User user) {
		Optional<User> ouser = uRepo.findById(userid);
		return uRepo.save(user);	
	}
}