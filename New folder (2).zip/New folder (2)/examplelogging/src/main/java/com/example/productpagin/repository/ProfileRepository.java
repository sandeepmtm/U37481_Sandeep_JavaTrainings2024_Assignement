package com.example.productpagin.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.example.productpagin.model.Profile;

public interface ProfileRepository extends JpaRepository<Profile, Long>{

}
