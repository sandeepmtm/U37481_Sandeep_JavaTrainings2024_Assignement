package com.example.productpagin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.productpagin.model.Profile;
import com.example.productpagin.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
}
