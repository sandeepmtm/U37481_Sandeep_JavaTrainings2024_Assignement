package com.service_package;

import java.util.Optional;
import com.data_package.Product;

public interface IInventoryService {
    void searchProductByName(String name);
    Product getProductById(int id);
}