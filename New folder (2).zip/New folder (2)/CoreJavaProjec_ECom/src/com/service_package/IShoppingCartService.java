package com.service_package;

public interface IShoppingCartService {
    void addProductToCart(int id, int quantity);
    void viewCart();
    void checkOut();
}