package com.app_package;

import java.util.Scanner;

import com.service_package.InventoryService;
import com.service_package.ShoppingCartService;

public class EcomApp {
	
	InventoryService inventserv=new InventoryService();
	ShoppingCartService shopcartserv=new ShoppingCartService();
	Scanner scanner=new Scanner(System.in);

	public static void main(String args[]) {
		
	EcomApp mainapp=new EcomApp();
	mainapp.run();
		
	}

	public void run() {
		while(true) {
			displayMenu();
			int choice=scanner.nextInt();
			//to move to new line
			scanner.nextLine();
			
			switch(choice) {
			
			case 1:searchProduct();
			break;
			case 2:addProductToCart();
			break;
			case 3:shopcartserv.viewCart();
			break;
			case 4:shopcartserv.checkOut();
			break;
			case 5:System.out.println("Exit from Console App");
			return;
			default:
			System.out.println("Invalid choice.Please try again.");

				
			}
		}
	}

	//Method to display Menu
	public void displayMenu() {
		System.out.println("Menu: ");
		System.out.println("1. Search for a Product");
		System.out.println("2. Add a Product to the cart");
		System.out.println("3. View Shopping Cart");
		System.out.println("4. Checkout");
		System.out.println("5. Exit");
		System.out.println("Enter your Choice");
	}

	//Method to search Product
	public void searchProduct() {
		System.out.println("Enter Product name: ");
		String name=scanner.nextLine();
		inventserv.searchProductByName(name);

		
	}

	//Method to addproduct to cart
	public void addProductToCart() {
		System.out.println("Enter Product id: ");
		int id=scanner.nextInt();
		System.out.println("Enter Quantity: ");
		int quantity=scanner.nextInt();
		shopcartserv.addProductToCart(id,quantity);
	}

	}



