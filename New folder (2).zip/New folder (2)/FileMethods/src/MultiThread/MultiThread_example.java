package MultiThread;

class PrintOdd extends Thread{
	String strc = "QWERTYUIOPP";
	/*
	 * @Override public void run() { try { for (int i=0;i<100;i+=2) {
	 * System.out.println("Child Thread"+i); Thread.sleep(50); } }catch(Exception e)
	 * { e.printStackTrace(); } }
	 */
	
	@Override
	public void run() { 
		try {
	for (int i=0;i<strc.length();i++) {
		System.out.println("Child Thread"+strc.charAt(i));	
		Thread.sleep(50);
	}
	}catch(Exception e) {
		e.printStackTrace();
	}
	}
}

public class MultiThread_example {
	
	public static void main(String arg[])
	{
		
		
		try {
		String str = "abcdefghijklmnopqrstuvwxyz";
		
		
		
		PrintOdd printodd = new PrintOdd();
		printodd.start();
		/*for (int i=0;i<100;i+=2) {
			System.out.println("Parent Tread"+i);	
			Thread.sleep(50);
		}
	}
		catch (Exception e) {
			e.printStackTrace();
		}*/
		for (int i=0;i<str.length();i++) {
			System.out.println("Parent Tread"+str.charAt(i));	
			Thread.sleep(50);
		}
	
		
		}catch (Exception e) {
			e.printStackTrace();
	}
	}
}
