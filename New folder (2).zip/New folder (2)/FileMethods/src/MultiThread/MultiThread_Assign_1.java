package MultiThread;


	

	class PrintWait extends Thread{
		
		String strc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		@Override
		public void run() { 
			try {
		for (int i=0;i<strc.length();i++) {
			System.out.println("Child Thread"+strc.charAt(i));	
			Thread.sleep(50);
		}
		}catch(Exception e) {
			e.printStackTrace();
		}
		}
	}

	public class MultiThread_Assign_1 {
		
		public static void main(String arg[])
		{
			
			
			try {
			String str = "abcdefghijklmnopqrstuvwxyz";
			
			
			
			PrintWait printodd = new PrintWait();
			printodd.start();
		
			for (int i=0;i<str.length();i++) {
				System.out.println("Parent Tread"+str.charAt(i));	
				Thread.sleep(50);
			}
		
			
			}catch (Exception e) {
				e.printStackTrace();
		}
		}
	}


