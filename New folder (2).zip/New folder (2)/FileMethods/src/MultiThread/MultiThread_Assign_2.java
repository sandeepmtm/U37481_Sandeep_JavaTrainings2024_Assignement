package MultiThread;



	class PrintOddWait extends Thread{
		
		
		@Override
		public void run() { 
			try {
		for (; MultiThread_Assign_2.getIndex() < MultiThread_Assign_2.getStr.length(); ) {
			System.out.println("Child Thread"+MultiThread_Assign_2.getStr.charAt(index));
			
			MultiThread_Assign_2.incrIndex();
			Thread.sleep(50);
		}
		}catch(Exception e) {
			e.printStackTrace();
		}
		}
	}

	public class MultiThread_Assign_2 {
		private static String str = "abcdefghijklmnopqrstuvwxyz";
		private static int index = 0;
		
		/**
		 * @return the str
		 */
		private static String getStr() {
			return str;
		}

		/**
		 * @param str the str to set
		 */
		private static void setStr(String str) {
			MultiThread_Assign_2.str = str;
		}

		
		/**
		 * @return the index
		 */
		private static int getIndex() {
			return index;
		}
		private static int incrIndex() {
			return index++;
		}
		/**
		 * @param index the index to set
		 */
		private static void setIndex(int index) {
			MultiThread_Assign_2.index = index;
		}

		public static void main(String arg[])
		{
			
			
			try {
			
			
			
			
			PrintOddWait printodd = new PrintOddWait();
			printodd.start();
			
			PrintOddWait printodd1 = new PrintOddWait();
			printodd1.start();
		
			for (;index<str.length();index++) {
				System.out.println("Parent Tread"+str.charAt(index));	
				Thread.sleep(50);
			}
		
			
			}catch (Exception e) {
				e.printStackTrace();
		}
		}
	}





