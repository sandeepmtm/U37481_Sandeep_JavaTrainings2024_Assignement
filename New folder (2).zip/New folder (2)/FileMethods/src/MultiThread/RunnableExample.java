package MultiThread;

class ChildThread implements Runnable{
	@Override
	public void run() {
		for (int i=0; i<100; i++) {
			try {
				System.out.println("child Thread"+i);
				Thread.sleep(100);
				}
					catch (Exception e){
					e.printStackTrace();
				}
					
				}
			}
		
	}
	


public class RunnableExample {
	public static void main(String arg[]) throws Exception
	{
		Thread t = new Thread (new ChildThread());
		t.start();
		for (int i=0; i<200; i++) {
		System.out.println("Main Thread"+i);
		Thread.sleep(100);
		}
	}

}
