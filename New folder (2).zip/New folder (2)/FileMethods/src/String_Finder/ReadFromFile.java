package String_Finder;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;

public class ReadFromFile {
	public static void main(String[] args) throws Exception {
	//	FileInputStream fis = new FileInputStream("./xyz.txt"); //bytes for one char byte wise reader 2 
		
		FileReader fis = new FileReader("./xyz.txt");//character by character read
		int c;
		while((c=fis.read())!=-1){
		System.out.print((char)c);}
		fis.close();
	}

}
