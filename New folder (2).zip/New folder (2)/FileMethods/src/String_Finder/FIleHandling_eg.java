package String_Finder;

import java.io.FileOutputStream;
import java.io.FileWriter;

public class FIleHandling_eg {
	public static void main(String[] args) throws Exception {
		//FileOutputStream fos = new FileOutputStream("./xyz.txt");
		FileWriter fos = new FileWriter("./xyz.txt", true);
		String ms = "Hello world";
//		byte[] arr = ms.getBytes();
		fos.write(ms);
		fos.close();
	}

}
