package String_Finder;

public class Exception_eg3108 {
	public static void main(String[] args) {
		try {
			
		String str ="abcd";
		String sustr =str.substring(1,8);
		
		
			int arr [] = {1,3,5,67,9};
		
			for(int i=0; i<=arr.length; i++) {
				System.out.println(arr[i]);
		}
			exc();
		
		}
		
		catch (StringIndexOutOfBoundsException se) { //exception handling statements
			System.out.println("String Outbound Exception occured....."+se);}
			
		
		catch (NumberFormatException ne) { //exception handling statements
		System.out.println("Number Exception occured....."+ne);}
		
		catch (ArrayIndexOutOfBoundsException ae) { //exception handling statements
			System.out.println("Array outbound Exception occured....." +ae);}
			
		
		
	
	
		
		catch (Exception e) { //exception handling statements
			System.out.println("Exception occured.....");}
			
		}
		
		
		static void exc() throws Exception { 
		
		//set of statements may throw exception errors
			System.out.println("1.....");
			String str = "erf";
			
			System.out.println("2.....");
			int val = Integer.parseInt(str);
			val *= 1.1;
			
			System.out.println(val);
			
		
			System.out.println("3.....");
	}
		
}



