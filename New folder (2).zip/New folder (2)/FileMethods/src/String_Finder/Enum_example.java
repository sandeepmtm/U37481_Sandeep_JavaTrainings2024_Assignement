package String_Finder;

import java.util.*;  

public class Enum_example {
	
	public static void main(String[] args) {
	
	

		 enum Days {
		      Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
		   }
		   
		      Days today = Days.Wednesday;
		      Days holiday = Days.Sunday;
		      System.out.println("Today = " + today);
		      System.out.println(holiday+ " is holiday");
		   
    }
}
