package String_Finder;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class ListMin {
	
	public static <T> void main(String[] args)
    {
		List<Integer> li = Arrays.asList(34,12,13,14,15,16);
		
		Collections.shuffle(li);
		
		 System.out.println("Try these methids:  " +li); 
		 TreeMap<Integer, String> tm1 = new TreeMap<Integer, String>();
			tm1.put(1,"ABC");		
		//	tm1.put(3/*key*/, "DEF"/*value*/);
			tm1.put(2, "HIJ");
			tm1.put(4, "LMN");
			tm1.put(5, "PQR");
			tm1.put(7, "XYZ");
			tm1.put(7, "STU");
			
			tm1.put(9, null);
			
		//	System.out.println("Value is: "+tm1.get(key));
			Set<?> s= tm1.entrySet();
			Iterator itr1 = s.iterator();
			while(itr1.hasNext())
			{
				Map.Entry me = (Map.Entry)itr1.next();
				System.out.println("Key:"+me.getKey()+" "+"value:"+me.getValue());
			}
			Collections.min((Collection<? extends T>) tm1);
			return;
    }
}
