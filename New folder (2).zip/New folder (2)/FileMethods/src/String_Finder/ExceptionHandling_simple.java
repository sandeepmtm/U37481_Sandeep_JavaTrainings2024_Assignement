package String_Finder;

public class ExceptionHandling_simple {
	public static void main(String[] args) {
		
	
		/*try {//set of statements may throw exception erros
		System.out.println("1.....");
		String str = "erf";
		
		System.out.println("2.....");
		int val = Integer.parseInt(str);
		val *= 1.1;
		
		System.out.println(val);
	}catch (Exception e) {//exception handling statements
		System.out.println("Exception occured.....");
	}
		System.out.println("3.....");
}*/
		try {
		exc();
		}
		catch (Exception e) { //exception handling statements
			System.out.println("Exception occured.....");}
		
		}
		
		
		static void exc() throws Exception { 
		
		//set of statements may throw exception errors
			System.out.println("1.....");
			String str = "erf";
			
			System.out.println("2.....");
			int val = Integer.parseInt(str);
			val *= 1.1;
			
			System.out.println(val);
		
			System.out.println("3.....");
	}
		
}
