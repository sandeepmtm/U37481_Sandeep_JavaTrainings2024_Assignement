package String_Finder;

import java.util.Arrays;
import java.util.List;

public class String_Finder_eg {
	
	

    
    private static final String Joiner = null;
	private static final String StringUtils = null;

	public static void main(String[] args)
    {
		 
	      String str = " Hello, Good, Morning"; 
	        
	      
	      String[] str1 = str.split(","); 
	        
	      
	      for(String str2 : str1)  
	      { 
	        if (str!=",")
	        System.out.println(str2); 
	        break;
	    } 
	  
}
}

