package Exception;

public class Exception_interface extends Exception {
	
	Exception_interface(String msg){
		super(msg);
		}
	
}
