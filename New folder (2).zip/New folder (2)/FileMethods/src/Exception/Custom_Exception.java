package Exception;

import java.util.Scanner;

public class Custom_Exception {
	
	public static void main(String[] args) {
		try {
			met();
		}		
		    catch (Exception_interface ie) {
			System.out.println("invalid error occured"+ie);
		}
}
		static void met() throws Exception_interface{
		
		Scanner scnr = new Scanner(System.in);
		System.out.println("enter your plan");
		
		int plan_id = scnr.nextInt();
		if(plan_id<1 ||plan_id>10 || plan_id==8) {
			throw new Exception_interface(plan_id+"  is invalid");
		}
		}
}
