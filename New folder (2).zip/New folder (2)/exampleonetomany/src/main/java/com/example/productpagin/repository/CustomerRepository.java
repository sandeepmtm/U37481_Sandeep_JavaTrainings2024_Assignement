package com.example.productpagin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.productpagin.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

}
