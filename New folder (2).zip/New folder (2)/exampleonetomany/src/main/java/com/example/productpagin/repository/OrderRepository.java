package com.example.productpagin.repository;

public interface OrderRepository extends JpaRepository<Ordering, Long>{
}
