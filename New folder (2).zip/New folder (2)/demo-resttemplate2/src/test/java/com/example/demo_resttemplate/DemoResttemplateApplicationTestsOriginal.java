package com.example.demo_resttemplate;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;
import org.springframework.test.web.servlet.*;

//import static java.lang.System.*;
@SpringBootTest
@AutoConfigureMockMvc
class DemoResttemplateApplicationTests {
	@Autowired
	private MockMvc mockMvc;

	private static Workbook wbook;

	private static Sheet st;

	private static int test_case_num;

	@BeforeAll
	static void metb() {
		/*
		 * // open or create excel(Test Report) // create workbook wbook = new
		 * XSSFWorkbook();
		 * 
		 * // create a new sheet st = wbook.createSheet("First Sheet"); test_case_num =
		 * 0;
		 */
		
		try {
	        // Define the path to the report file
	        Path reportPath = Path.of("D:\\Softwares\\testreport.xlsx");
	        
	        // Delete the existing file if it exists
	        if (Files.exists(reportPath)) {
	            Files.delete(reportPath);
	        }

	        // Create a new workbook and sheet
	        wbook = new XSSFWorkbook();
	        st = wbook.createSheet("First Sheet");
	        test_case_num = 0;
	    } catch (Exception e) {
	        System.err.println("Error initializing test report: " + e.getMessage());
	    }
	}

	@BeforeEach
	void met() {

	}

	// can be moved to different Java file
	private static Stream<Arguments> fetchTicketIds() {
		List<Arguments> args = new ArrayList<>();
		try {
			// read Testdata from excel
			FileInputStream fis = new FileInputStream("D:\\Softwares\\restparam.xlsx");

			// read workbook
			Workbook wbook = new XSSFWorkbook(fis);

			double value = 0;

			int no_of_rows = 0;
			Sheet st = null;

			// read sheet
			st = wbook.getSheetAt(0);

			// fetch number of rows in excel
			no_of_rows = st.getPhysicalNumberOfRows();

			for (int i = 0; i < no_of_rows; i++) {
				// fetch each row
				Row row = st.getRow(i);

				int no_of_cols = row.getLastCellNum();

				// read first column - ticket id
				Cell cell1 = row.getCell(0);
				int ticketid = (int) cell1.getNumericCellValue();

				// read second col - fromplace
				Cell cell2 = row.getCell(1);
				String fromplace = cell2.getStringCellValue();

				// read third col - toplace
				Cell cell3 = row.getCell(2);
				String toplace = cell3.getStringCellValue();

				Cell price_cell = row.getCell(3);
				float price = (float) price_cell.getNumericCellValue();

				// add each Test data bundle to List
				args.add(Arguments.of(ticketid, fromplace, toplace, price));
			}

			wbook.close();
			fis.close();
		} catch (Exception e) {
			System.out.println("Exceptionnnn:" + e.getMessage());
			e.printStackTrace();
		}

		// create and return Stream from List of JUnit Arguments
		return args.stream();
	}

	/*
	 * //Retrieving Hard coded Test Data private static Stream<Arguments>
	 * fetchTicketIds(){ return Stream.of(Arguments.of(8,"pqrs","mnop"),
	 * Arguments.of(9,"ggggg","hhhh"), Arguments.of(10,"ggggg","hhhh") ); }
	 */

	@ParameterizedTest
	@MethodSource("fetchTicketIds")
	void testGetTicket(int ticketid, String fromplace, String toplace, float price) throws Exception {
		try {
			ResultActions resultActions = mockMvc.perform(get("/redbus/" + ticketid)) // Sending GET request with url
					.andExpect(status().isOk()) // checking response Http Status code
					// below, checking response Content Type
					.andExpect(content().contentType(MediaType.APPLICATION_JSON))
					.andExpect(jsonPath("$.fromplace").value(fromplace)).andExpect(jsonPath("$.toplace").value(toplace))
					.andExpect(jsonPath("$.price").value(price));
			// .andDo(print());

			String jsonresponse = resultActions.andReturn().getResponse().getContentAsString();

			System.out.println("Json Responsee:" + jsonresponse);

			// Student student = new ObjectMapper() //.readValue(jsonString,
			// Student.class);

			// json string to java object
			ObjectMapper omapper = new ObjectMapper();

			Ticket ticket = omapper.readValue(jsonresponse, Ticket.class);

			System.out.println("From Placeee:" + ticket.getFromplace());
		} catch (AssertionError ae) { // this exception check the test cases pass or fails
			/*
			 * // create row Row row = st.createRow(test_case_num);
			 * 
			 * // in above row, create cell, and set some value Cell cell =
			 * row.createCell(0, CellType.STRING); cell.setCellValue("TestCase: Failed");
			 */

			// create row excel
			createTestResultRow("TestCase: Failed");
			System.out.println(ae.getMessage());
			throw ae; // if we are not adding this "throw", during failure time, it gave success and message as fail
		} catch (Exception e) {
			System.out.println(e.getMessage());
			// e.printStackTrace();
		}

		
		createTestResultRow("TestCase: Passed");

		System.out.println("Testcase: Passed");
		System.out.println("----------------------------------------");
	}
	
	private void createTestResultRow(String result) {
		// create row in excel
				// create row
				Row row = st.createRow(test_case_num);

				// in above row, create cell, and set some value
				Cell cell = row.createCell(0, CellType.STRING);
				cell.setCellValue(result);
				
				System.out.println(result);
	}

	@AfterEach
	void metae() {
		test_case_num++;
	}

	@AfterAll
	static void meta() {
		try {
			// close excel
			FileOutputStream fos = new FileOutputStream("D:\\Softwares\\testreport.xlsx");

			// write above excel to a file
			wbook.write(fos);
			wbook.close();
			fos.close();
		} catch (Exception e) {
			System.out.println("Error writing test report: " + e.getMessage());
		}
	}
	// id which doesnt exist
	// not int id

	// @Test
	@Disabled
	void testBookTicket() throws Exception {
		mockMvc.perform(post("/redbus").contentType(MediaType.APPLICATION_JSON)
				.content("{\"username\":\"user456\"," + "\"fromplace\":\"tuvw\"," + "\"toplace\":\"klmn\","
						+ "\"email\":\"987652@gmail.com\", " + "\"price\":9876.5}"))
				.andExpect(status().isCreated()).andExpect(content().contentType(MediaType.APPLICATION_JSON))
				.andDo(print()).andExpect(jsonPath("$.username").value("user456"));
	}

	// @Test
	@Disabled
	void testUpdateTicket() throws Exception {
		mockMvc.perform(put("/redbus/27").contentType(MediaType.APPLICATION_JSON).content(
				// "{\"username\":\"user456\","+
				"{\"fromplace\":\"jjjjjj\"," + "\"toplace\":\"kkkk\"," + "\"email\":\"987652@gmail.com\", "
						+ "\"price\":9876.5}"))
				.andExpect(status().isCreated());
	}

	// @Test
	@Disabled
	void cancelTicket() throws Exception {
		mockMvc.perform(delete("/redbus/27")).andExpect(status().isOk());

	}

}
