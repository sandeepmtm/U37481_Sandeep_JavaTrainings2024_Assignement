package com.selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LocateByClass {
	public static void main(String[] args) throws InterruptedException 
	{ 
	// set driver property
	
	System.setProperty("webdriver.chrome.driver","C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
	
	// create driver instance
	WebDriver driver = new ChromeDriver();
	
	//load the page under test
	driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\LocateByClass.html");

	// wait until the page loaded
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
	
	WebElement submitButton = driver.findElement(By.className("button"));
	
	WebElement submit = wait.until(ExpectedConditions.elementToBeClickable(By.className("button")));
	// click button
	Thread.sleep(1000);
	submit.click();
	

	
	WebElement messageView = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("button")));
	
	String printMessage = messageView.getText();
	
	System.out.println("Message after clicking button: "+printMessage);
	
	Thread.sleep(5000);
	driver.quit();
	
}
}