package com.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FirstSeleniumExample {
	// Driver code 
		public static void main(String[] args) throws InterruptedException 
		{ 
			// chrome driver path
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
			
			//create instance from web driver
			WebDriver driver = new ChromeDriver();
			
			// to get request from web page
			driver.get("http://www.example.com");
			
			//perform operations from the loaded web page
			
			String title = driver.getTitle();
			System.out.println("Webpage title: " +title);
			
			Thread.sleep(3000);
			
			driver.quit();
			
			
		}

}
