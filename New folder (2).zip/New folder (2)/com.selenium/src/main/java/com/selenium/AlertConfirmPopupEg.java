package com.selenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertConfirmPopupEg {
	public static void main(String[] args)  throws InterruptedException
	{ 
	try {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
	
	WebDriver driver = new ChromeDriver();
	
	driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\AlertConfirmPromptEg2.html");

	
	//test alert
	testAlert(driver);
	
	//test confirm
	testConfirm(driver);
	
	//test prompt
	testPrompt(driver);
	driver.quit();
	
	
	}catch (Exception e) {
		e.printStackTrace();
	}
}
	private static void testAlert(WebDriver driver) throws InterruptedException{
		WebElement alertButton = driver.findElement(By.xpath("//button[text()='Show Alert']"));

		alertButton.click();

		Thread.sleep(2000);
		Alert alert = driver.switchTo().alert();
		System.out.println(alert.getText());
		alert.accept();

		Thread.sleep(2000);

	}

	private static void testConfirm(WebDriver driver) throws InterruptedException{
		WebElement alertButton = driver.findElement(By.xpath("//button[text()='Show Confirm']"));

		alertButton.click();

		Thread.sleep(2000);
		Alert alert = driver.switchTo().alert();
		System.out.println(alert.getText());
		alert.accept();

		Thread.sleep(2000);

	}

	private static void testPrompt(WebDriver driver) throws InterruptedException{
		WebElement alertButton = driver.findElement(By.id("prompt"));

		alertButton.click();

		Thread.sleep(2000);
		Alert alert = driver.switchTo().alert();
		System.out.println(alert.getText());
		alert.sendKeys("hello world");
		Thread.sleep(2000);
		alert.accept();

		Thread.sleep(2000);

	}
	
}
