package com.selenium;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Screenshots {
	public static void main(String[] args) 
	{ 
		try {
	// set driver property
	
	System.setProperty("webdriver.chrome.driver","C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
	
	// create driver instance
	WebDriver driver = new ChromeDriver();
	
	//load the page under test
	driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\Screenshots.html");

	// wait until the page loaded
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
	
	
	
	File screenshot4 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	FileHandler.copy(screenshot4, new File("./screenshot4.png"));
	driver.quit();
		}catch (Exception e){
			System.out.println(e.getMessage());
			
		}
		
		
}
	
}