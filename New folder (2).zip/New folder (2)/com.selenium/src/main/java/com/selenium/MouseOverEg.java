package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class MouseOverEg {
	public static void main(String[] args)  throws InterruptedException
	{ 
	try {
		// chrome driver path
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
	
	//create instance from web driver
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	
	//load the page under test
	driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\MouseOverEg.html");
	
	//// locate we elements that required actions
	WebElement clickButton = driver.findElement(By.id("clickButton"));
	WebElement hoverDiv = driver.findElement(By.id("hoverDiv"));
	WebElement doubleClickButton = driver.findElement(By.id("doubleClickButton"));
	WebElement dragDiv = driver.findElement(By.id("dragDiv"));
	WebElement dropArea = driver.findElement(By.id("dropArea"));
	
	
	Actions action = new Actions(driver);
	
	Thread.sleep(2000);
	action.click(clickButton).perform();
	System.out.println("Button clicked: "+clickButton.isDisplayed());
	
	Thread.sleep(2000);
	action.moveToElement(hoverDiv).perform();
	System.out.println("Hovering: "+hoverDiv.isDisplayed());
	System.out.println("Message: "+hoverDiv.getText());
	
	Thread.sleep(2000);
	action.click(clickButton).perform();
	System.out.println("Button clicked: "+clickButton.isDisplayed());
	System.out.println("Message: "+clickButton.getText());
	
	Thread.sleep(2000);
	action.doubleClick(doubleClickButton).perform();
	System.out.println("Double clicked: "+doubleClickButton.isDisplayed());
	System.out.println("Message: "+doubleClickButton.getText());
	
	Thread.sleep(2000);
	action.contextClick(clickButton).perform();
	System.out.println("Right clicked: "+clickButton.isDisplayed());
	System.out.println("Message: "+clickButton.getText());
	
	Thread.sleep(2000);
	action.dragAndDrop(dragDiv, dropArea).perform();
//	action.clickAndHold(dragDiv).moveToElement(dropArea).release().perform();
	System.out.println("Drag and drop: "+dropArea.isDisplayed());
	System.out.println("Message: "+dropArea.getText());
	
	Thread.sleep(4000);

	driver.quit();
	
	}catch (Exception e) {
		e.printStackTrace();
	}
	
}


}
