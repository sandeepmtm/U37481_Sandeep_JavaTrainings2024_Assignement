package com.selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class LocateByNameAdvanced {
	
	public static void main(String[] args) throws InterruptedException 
	{ 
	// set driver property
	
	System.setProperty("webdriver.chrome.driver","C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
	
	// create driver instance
	WebDriver driver = new ChromeDriver();
	
	//load the page under test
	driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\LocateByNameEg.html");

	// wait until the page loaded
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	
	// wait until page loaded successfully
	WebElement userNameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
	// enter text user name field
	userNameField.sendKeys("username");
	
	
	// locate age
	WebElement ageField = driver.findElement(By.name("age"));
	// enter age
	ageField.sendKeys(String.valueOf(35));
	
	WebElement setEmail = driver.findElement(By.name("email"));
	setEmail.sendKeys("sandeep@ust.com");
	
	//set country
	WebElement setCountry = driver.findElement(By.name("country"));
	setCountry.sendKeys("Canada");
	
	// locate button
	WebElement submitButton = driver.findElement(By.id("submitButton"));
	//Thread.sleep(2000);
	// click button
	submitButton.click();
	//wait for message to be visible
	
	
	

	//WebElement messageDisplay = driver.findElement(By.id("message"));
	
	//wait for message to be visible and get updated message text
	WebElement messageDiv = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("message")));
	
	String printMessage = messageDiv.getText();
	System.out.println("Message after clicking button: "+printMessage);
	
	Thread.sleep(10000);
	driver.quit();
	}

}
