package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByXpath {
	public static void main(String[] args) throws Exception 
	{ 
	try {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
	
	WebDriver driver = new ChromeDriver();
	
	driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\Xpath.html");

	WebElement element = driver.findElement(By.xpath("/html/body/form/input[1]")); // full XML path (Xpath)
	element.sendKeys("username");
	Thread.sleep(500);
	WebElement elementx = driver.findElement(By.xpath("//*[@id=\"password\"]")); //relative Xpath - @ is attribute and other is value
	elementx.sendKeys("password");
	
	System.out.println(element.getAttribute("value"));
	
	System.out.println(elementx.getAttribute("value"));
	Thread.sleep(500);
	//WebElement elementb = driver.findElement(By.xpath("//button[text()='Login']")); //find xpath with text name as "Login"
//	WebElement elementb = driver.findElement(By.xpath("//button[contains(text(),'in')]")); //find xpath with text name contains "in"
	
	WebElement elementb = driver.findElement(By.xpath("//button[starts-with(text(),'Log')]")); //find xpath with text name contains "in"
	
//	WebElement elementb = driver.findElement(By.xpath("//button[end-with(text(),'in')]")); //find xpath with text name contains "in"
	
	Thread.sleep(1000);
	elementb.click();
	
	Thread.sleep(3000);
	

	driver.quit();
	} catch (Exception e) {
		e.printStackTrace();
	}
	}
}
