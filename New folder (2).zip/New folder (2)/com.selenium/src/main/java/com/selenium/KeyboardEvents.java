package com.selenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class KeyboardEvents {
	
	public static void main(String[] args)  throws InterruptedException
	{ 
	try {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
	
	WebDriver driver = new ChromeDriver();
	
	driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\KeyboardEventsEg.html");
	
	WebElement inputField = driver.findElement(By.id("inputField"));
	Thread.sleep(2000);
	inputField.sendKeys("hello world");
	//inputField.click();

	Thread.sleep(2000);
	inputField.sendKeys(Keys.BACK_SPACE+""+Keys.BACK_SPACE); //backspace given after entering text field value. we can loop if we want more backspaces
	Thread.sleep(1000);
	inputField.sendKeys(Keys.CONTROL+""+"A"); // selected the added text
	System.out.println(inputField.getAttribute("value"));
	Thread.sleep(1000);
	inputField.sendKeys(Keys.TAB); 
	Thread.sleep(1000);
	driver.findElement(By.id("submitButton")).sendKeys(Keys.ENTER);
	Thread.sleep(2000);
	System.out.println(driver.findElement(By.id("output")).getText());
	driver.quit();
	}catch (Exception e) {
		e.printStackTrace();
	}
	
}
	
}
