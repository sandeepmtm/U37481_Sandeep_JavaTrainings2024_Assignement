package com.selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByCSS {
	public static void main(String[] args) throws Exception 
	{ 
	
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
	
	WebDriver driver = new ChromeDriver();
	
	driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\LocateByCss.html");
//	
	
	// locate by CSS selector by Class
  
    
	//WebElement element = driver.findElement(By.cssSelector(".input-field"));
	//WebElement element = driver.findElement(By.cssSelector("input.input-field"));
	
	// locate by CSS selector by Id
	  //NoSuchElementException
	//WebElement elements = driver.findElement(By.cssSelector("input#some-id")); //(".some-id")
	
	//locate by CSS selector by input tag
	//WebElement elements = driver.findElement(By.cssSelector("input[type='password']"));
	
	// locate by CSS selector by parent child form
	WebElement element = driver.findElement(By.cssSelector("form input"));
	element.sendKeys("username");
	System.out.println(element.getAttribute("value"));
	
	
	//// locate by CSS selector by OR
	List<WebElement> elements = driver.findElements(By.cssSelector("input#some-id, .input-field"));
	
	
		//element.sendKeys("test the input fields");
		elements.stream().forEach((e)->{System.out.println("--->"+e.getAttribute("type"));});
		
		//System.out.println(element.getAttribute("value"));
	//	System.out.println(elements.getAttribute("value"));
		
		
		// locate by CSS selector by AND
		
		WebElement elementa = driver.findElement(By.cssSelector("input#some-id.input-field"));
		
		System.out.println(elementa.getTagName()+"  " +elementa.getAttribute("type"));
		
	
	Thread.sleep(3000);
	

driver.quit();
	}
}