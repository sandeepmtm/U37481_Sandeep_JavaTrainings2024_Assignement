package com.selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByTag {
	
	public static void main(String[] args) throws InterruptedException 
	{ 
	
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
	
	WebDriver driver = new ChromeDriver();
	
	driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\LocateByName.html");
//	WebElement element = driver.findElement(By.tagName("username"));
	
	//locate by Tag "no of input tags" from this html <input type="text" name="username" placeholder="Enter your username">
    //<input type="password" name="password" placeholder="Enter your password">
  
    
	List<WebElement> elements = driver.findElements(By.tagName("input"));
	
	for (WebElement element : elements) {
		element.sendKeys("some text here");
		System.out.println(element.getAttribute("name"));
	}
	
	Thread.sleep(3000);
	driver.quit();
}
	
}
