package com.selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.File;
import org.openqa.selenium.TakesScreenshot;


public class LocateByLinkText {
	public static void main(String[] args) throws Exception 
	{ 
	// set driver property
	
	System.setProperty("webdriver.chrome.driver","C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
	
	// create driver instance
	WebDriver driver = new ChromeDriver();
	
	//load the page under test
	driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\LocateByLinkText.html");

	// wait until the page loaded
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
	
	WebElement linkText = driver.findElement(By.linkText("Visit Example"));
	
//	WebElement submit = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Visit Example")));
	// click button
	Thread.sleep(1000);
	//take scree-shot of landing page
	File screenshot1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	FileHandler.copy(screenshot1, new File("./screenshot1.png"));
	
	linkText.click();
	System.out.println("Message after clicking button: "+driver.getTitle());
	
	//take scree-shot of navigated page
	File screenshot2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	FileHandler.copy(screenshot2, new File("./screenshot2.png"));
	
	WebElement partiallinkText = driver.findElement(By.partialLinkText("information"));
	Thread.sleep(1000);
	
	
	partiallinkText.click();
	System.out.println("Message after clicking the next button: "+driver.getTitle());
	//take scree-shot of navigated next page
	File screenshot3 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	FileHandler.copy(screenshot3, new File("./screenshot3.png"));
	
	Thread.sleep(5000);
	driver.quit();
	
}

}
