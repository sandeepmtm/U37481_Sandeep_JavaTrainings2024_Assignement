package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HTMLFormEg {
	public static void main(String[] args)  throws InterruptedException
	{ 
	try {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
	
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	
	driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\HTMLFormEg.html");
	
	WebElement usernameField = driver.findElement(By.id("username"));
	WebElement maleRadio = driver.findElement(By.id("male"));
	WebElement femaleRadio = driver.findElement(By.id("female"));
	WebElement subCheckbox = driver.findElement(By.id("subscribe"));
	WebElement dropdown = driver.findElement(By.id("dropdown"));
	WebElement submitButton = driver.findElement(By.id("submitBtn"));
	WebElement message = driver.findElement(By.id("message"));
	
	Thread.sleep(1000);
	usernameField.sendKeys("Suraj");
	System.out.println("Usen Name entered: "+usernameField.getAttribute("value"));
	
	Thread.sleep(1000);
	maleRadio.click();
	String rad = maleRadio.isSelected()? "Male":"Female";
	System.out.println("Radio Button selected: "+rad);
	
	Thread.sleep(1000);
	subCheckbox.click();
	System.out.println("Checkbox selected: "+subCheckbox.isSelected());
	
	Thread.sleep(1000);
	Select dropdownSelect = new Select (dropdown);
//	dropdownSelect.selectByValue("option2");
	dropdownSelect.selectByVisibleText("Option 2");
	System.out.println("Dropdown selected: "+dropdownSelect.getFirstSelectedOption().getText());
	
	Thread.sleep(3000);
	submitButton.sendKeys(Keys.ENTER);
	Thread.sleep(2000);
	System.out.println("Submitted message: "+message.getText());
	
	Thread.sleep(4000);

	driver.quit();
	
	}catch (Exception e) {
		e.printStackTrace();
	}
	
}

}
