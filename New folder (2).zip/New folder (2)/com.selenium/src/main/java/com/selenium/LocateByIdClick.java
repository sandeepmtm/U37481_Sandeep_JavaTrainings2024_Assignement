package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByIdClick {
	public static void main(String[] args) throws InterruptedException 
	{ 
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\LocateByIdEg.html");
		
		
		WebElement submitButton = driver.findElement(By.id("testButton"));
		Thread.sleep(10000);
		submitButton.click();
		Thread.sleep(10000);
		
		WebElement messageField = driver.findElement(By.id("message"));
		String printMessage = messageField.getText();
		Thread.sleep(3000);
		System.out.println("Message after clicking button: "+printMessage);
		
		driver.quit();
	}


}
