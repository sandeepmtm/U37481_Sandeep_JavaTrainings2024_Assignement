/**
 * 
 */
/**
 * 
 */
module EcommerceConsoleApplication {
}