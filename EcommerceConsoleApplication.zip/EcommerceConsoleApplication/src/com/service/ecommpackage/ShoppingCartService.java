package com.service.ecommpackage;
import com.data.ecommpackage.Product;
import com.data.ecommpackage.ShoppingCart;

public class ShoppingCartService {
	private ShoppingCart shopcart=new ShoppingCart();
private	InventoryService inventserv=new InventoryService();
	
//method to add a product to the cart
	public void addProductToCart(int id,int quantity) {
	Product product=inventserv.getProductById(id);
	if(product!=null) {
		shopcart.addProductsToShoppingCart(product,quantity);
		System.out.println("Product added to Cart");
	}
		else {
			System.out.println("Product not found");
		}
	}
	
	
//Method to view items in Cart
public void viewCart() {
	shopcart.viewShoppingCart();
}



//Method to checkout items in Cart
public void checkOut() {
	shopcart.checkoutShoppingCart();
}
}
