package com.service.ecommpackage;

import java.util.Optional;

import com.data.ecommpackage.Inventory;
import com.data.ecommpackage.Product;

public class InventoryService {

	Inventory  inventory=new Inventory();
	
//Method to search for a product by name and display its details
	
	public void searchProductByName(String name) {
	Optional<Product>product=inventory.searchProductByName(name);
	if(product.isPresent()) {
		Product p=product.get();
		System.out.println("Product found. ProductName: "+ p.getProduct_name()+", Categories: " + p.getProduct_category() + "and   Price: " + p.getPrice());
	
	}
	else {
		System.out.println("Product not found");

	}
}
//Method to get a product by its id
	
	public Product  getProductById(int id) {
		return inventory.getProductById(id);
		
	}
}