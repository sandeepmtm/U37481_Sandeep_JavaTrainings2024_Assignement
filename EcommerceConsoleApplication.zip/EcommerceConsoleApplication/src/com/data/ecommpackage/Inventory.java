package com.data.ecommpackage;

import java.util.ArrayList;
import java.util.Optional;


public class Inventory {
	
//Create a list of products in store
	ArrayList<Product> storeproducts=new ArrayList<Product>();
	
	//Constructor to initialize the inventory with some products
	
	public Inventory(){
		storeproducts.add(new Product(1, "Watch", "Electronics", 3000.0));
		storeproducts.add(new Product(2, "Mobile", "Electronics", 100000.0));
		storeproducts.add(new Product(3, "Laptop", "Electronics", 50000.0));
		storeproducts.add(new Product(4, "Swim Suite", "Clothing", 2000.0));
		storeproducts.add(new Product(5, "Jeans", "Clothing", 500.0));
		storeproducts.add(new Product(6, "Skirt", "Clothing", 600.0));
		storeproducts.add(new Product(7, "Fresh Vegitables", "Grocery", 350.0));
		storeproducts.add(new Product(8, "Canned Food", "Grocery", 200.0));
		storeproducts.add(new Product(9, "Oils", "Grocery", 50.0));
		storeproducts.add(new Product(10,"Fresh Fruits", "Grocery", 100.0));

}

//Method to search for a product by its name

public  Optional<Product> searchProductByName(String name) {
return storeproducts.stream().filter(product->product.getProduct_name().equalsIgnoreCase(name)).findFirst();
//equalignore method compare 2 string without checking lowercase/uppercase
}


//Method to search for a product by its id

public Product getProductById(int id) {
	for(Product product:storeproducts) {
		
		if(product.getProduct_id()==id) {
			return product;
		}
	}
	return null;
}

}

