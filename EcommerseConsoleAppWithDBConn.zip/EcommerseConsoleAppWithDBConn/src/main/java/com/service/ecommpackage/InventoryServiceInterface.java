package com.service.ecommpackage;

import com.data.ecommpackage.Product;

public interface InventoryServiceInterface {
	
void searchProductByName(String name);
Product getProductById(int id);

}
