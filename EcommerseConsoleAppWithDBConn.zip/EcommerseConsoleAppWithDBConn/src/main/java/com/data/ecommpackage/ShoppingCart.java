package com.data.ecommpackage;
import java.util.ArrayList;

public class ShoppingCart {
	
// List to store  Cart items ..used Composition
	private ArrayList<CartItem> items=new ArrayList<>();
	
	
	
//Method to add Products to Shopping cart

public  void addProductsToShoppingCart(Product  product,int quantity) {
	for(CartItem item:items) {
//check if product is already in the cart
	if(item.getproductid()==product.getProduct_id()) {
		item.setquantity(item.getquantity()+quantity);
		return;
	}
	}
	items.add(new CartItem(product.getProduct_id(),quantity,product.getPrice()));
		
	}

//Method to view Products in Shopping cart
	public   void viewShoppingCart() {
		
		System.out.println("Shopping Cart:");
		for(CartItem item:items) {
			System.out.println("Product ID: " + item.getproductid()+
					", Quantity: " + item.getquantity()+
					", Price per unit: " + item.getprice()+
					", Total: " + (item.getquantity()*item.getprice()));
		}
	}
	
//Method to checkout Products and display total amount 

public  void checkoutShoppingCart() {
	double total=0;
	System.out.println("checkout:");
	for(CartItem item:items) {
double subtotal=item.getquantity()*item.getprice();
System.out.println("Product ID: " + item.getproductid()+ 
		", Quantity: " + item.getquantity()+
		", Price per unit: " + item.getprice()+
		", Subtotal: " + subtotal);
total+=subtotal;
}
	System.out.println("Total Amount:"+ total);

	}


//private innerclass to store each items details in  shopping cart
private static class  CartItem{
	private int productid;
	private int quantity;
	private  double price;
	//Constructor to initialize CartItem
	 public CartItem(int productid,int quantity,double price) {
		 this.productid=productid;
		 this.quantity=quantity;
		 this.price=price;
	 }
	 //Getters and setters for CartItem
	 public int getproductid() {
		 return productid;
	 }
	 
 public void setproductid(int productid) {
	 this.productid=productid;
 }
	 
	 public int getquantity() {
		 return quantity;
	 }
	 
	 public void setquantity(int quantity) {
		 this.quantity=quantity;
	 }
	 
	 public double getprice() {
		 return price;
	 }
	 
//	 public void setprice(double price) {
//		 this.price=price;
//	 }
	 	 
	 }
}

