package com.data.ecommpackage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//DB Is ConsoleApp and Table is Products

public class DBDataFetch {
			private Connection connection;
		
			
//Constructor
		public DBDataFetch(Connection connection) {
		this.connection=connection;
		}
		
		
//Method to search Product by name
		public  Product searchProductByName(String name) {
			//System.out.println("DBDataFetch Entry to search method is working");
			try {
			String Query="select * from Products where Product_name=?";
			PreparedStatement pst=connection.prepareStatement(Query);
			pst.setString(1,name);
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
			return new Product(
			rs.getInt("Product_id"),
			rs.getString("Product_name"),
	    	rs.getString("Product_category"),
			rs.getDouble("Price"));
			
			}
		
		}catch(SQLException e) {
			e.printStackTrace();
			}
		return null;
	}
		
//Method to get Product by id	

			public Product getProductById(int id) {
		    try {
			String Query="Select * from Products where Product_id=?";
			PreparedStatement pst=connection.prepareStatement(Query);//SQL Injection
			pst.setInt(1, id);
	        ResultSet rs=pst.executeQuery();
	        if(rs.next()) {
	          return new Product(
	        	rs.getInt("Product_id"),
	        	rs.getString("Product_name"),
	        	rs.getString("Product_category"),
	        	rs.getDouble("Price")
	        	);
	        }
		    }catch(SQLException e) {
		    	e.printStackTrace();
		    }
	return null;//return null if not found
		}
	
}
