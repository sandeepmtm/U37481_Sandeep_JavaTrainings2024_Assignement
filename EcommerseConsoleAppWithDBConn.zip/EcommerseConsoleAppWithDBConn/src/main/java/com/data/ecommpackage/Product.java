package com.data.ecommpackage;

public class Product {

//To Declare Product Attributes/Variables
	
	private int Product_id;
	private String Product_name;
	private String Product_category;
	private double Price;
	
	//Constructor,to initialize a Product 
	public Product(int Product_id,String Product_name,String Product_category, double Price) {
		this.Product_id=Product_id;
		this.Product_name=Product_name;
		this.Product_category=Product_category;
		this.Price=Price;
	}
	
	//Getters and setters to access and set the properties of the product 
	//Implement getters and setters for Product id
	public int getProduct_id() {
		return Product_id;
	}
	
	public void setProduct_id(int id) {
		this.Product_id=id;
	}
	
	
	//Implement getters and setters for Product name

	public String getProduct_name() {
		return Product_name;
	}

	public void setProductname(String name) {
		this.Product_name=name;
	}
	
	
	//Implement getters and setters for Product Category
	
	public String getProduct_category() {
		return Product_category;
	}
 
	public void setProduct_category(String department) {
		this.Product_category=department;
	}
	
	
	//Implement getters and setters for Product Price
	
	public double getPrice() {
		return Price;
	}

	public void setPrice(float amount) {
		this.Price=amount;
	}
	


}
